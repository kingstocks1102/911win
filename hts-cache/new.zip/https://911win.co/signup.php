 
 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-TW">
<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170206988-1"></script>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());
		gtag('config', 'UA-170206988-1');
	</script>
	<!-- Google Tag Manager -->
	<script>
		(function(w,d,s,l,i){
			w[l]=w[l]||[];
			w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});
			var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';
			j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;
			f.parentNode.insertBefore(j,f);
		})(window,document,'script','dataLayer','GTM-KH7FG9T');
	</script>
	<!-- End Google Tag Manager -->
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="Content-Script-Type" content="text/javascript">
    <meta http-equiv="Content-Style-Type" content="text/css">
    <title>911 Casino | Most people play online games, live video, baccarat, sapphire, bingo planet, cypress slot, super eight, fruit plate, little Mary, slot machine, mahjong, Texas Hold'em!-sign up</title>
    <meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <meta HTTP-EQUIV="Cache-Control" CONTENT="no-cache">
    <meta HTTP-EQUIV="Expires" CONTENT="0">
    <meta http-equiv="Content-Language" content="zh-tw" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="911win casino, 911win, casino, online casino, bet, baccarat, live baccarat, online bet, slots, bonus, World Cup 2022, Esports, E-games, poker, holdem, video poker, roulette, crypto, ETH, USDT, Evolution" />
    <meta property="og:title" content="911win Casino│Online casino│Baccarat│Poker online│Roulette" />
    <meta property="og:keywords" content="casino, football Euro, World Cup 2022, FIFA, LoL, lottery, Esports, sports, poker online, slots, slot game" />
    <meta itemprop="name" content="911win Casino sign up, bonus, first deposit, 100% deposit bonus, baccarat recommended, bacarrat betting">
    <meta itemprop="keywords" content="online casino, gambling, bet, baccarat casino, macau baccarat ,best casino online, online betting">
    <meta name="description" itemprop="description" content="911win Casino sign up, first deposit, 100% deposit bonus, casino online recommended, baccarat, betting online, sports betting, E-games, lottery games, the best casino">
    <meta name="author" content="baccarat, Sports betting, slot game, slots, 911win Casino">
    <meta name="copyright" content="baccarat, holdem, poker game, 911win Casino">
    <meta content='website' property='og:type' />
    <meta property="og:image" content="http://www.911win.co/images/ch/91logo-5.png">
    <meta property="og:url" content="http://www.911win.co" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:description" content="Trang web giải trí 911 Promotion, tặng 700,000 cho lần nạp đầu, tặng thưởng cho Novice, tặng phí giới thiệu cho người chơi cũ, CSKH 24/7, Withdrawal now chóng. Còn có nhiều hoạt động giải trí như giải đấu Sports, bài cào Baccarat, Lottery, egames, SLOT..., vui đã đời. Chuyên nghiệp, nhanh chóng, an toàn, 911 Casino, trang web giải trí được đề xuất" />
    <meta name="twitter:title" content="【911 Casino】｜Trang web giải trí 911-Trang web giải trí trực tuyến được bình chọn｜Promotion｜LIVE CASINO 2021" />
    <!-- Chrome, Firefox OS and Opera -->
    <meta name="theme-color" content="#222222">
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#222222">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-status-bar-style" content="#222222">
    <link rel="manifest" href="manifest.json">
    <script type="application/x-javascript">
        addEventListener("load", function() {
            setTimeout(hideURLbar, 0);
        }, false);
		
        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- //for-mobile-apps -->
    <script type="text/javascript" src="../../js/sweetalert.min.js"></script>
    <!-- banner-slider -->
    <link href="../../css/mo/jquery.slidey.min.css" rel="stylesheet">
    <!-- //banner-slider -->
    <!-- web app icon -->
    <link rel="apple-touch-icon" href="../../images/ch/icon57.png">
    <!-- 57×57px -->
    <link rel="apple-touch-icon" sizes="72×72" href="../../images/ch/icon72.png">
    <!-- 72×72px ipad-->
    <link rel="apple-touch-icon" sizes="114×114" href="../../images/ch/icon114.png">
    <!-- 114×114px iphone4-->
    <link rel="icon" sizes="192x192" href="../../images/ch/icon192.png">
    <link rel="icon" sizes="128x128" href="../../images/ch/icon128.png">
    <link rel="apple-touch-icon" sizes="128x128" href="../../images/ch/icon128.png">
    <link rel="apple-touch-icon-precomposed" sizes="128x128" href="../../images/ch/icon128.png">
    <!-- web app icon end-->
    <!-- js -->
    <script type="text/javascript" src="../../js/jquery-2.1.4.min.js"></script>
    <!-- //js -->
    <!-- banner-bottom-plugin -->
    <link href="../../css/mo/owl.carousel.css" rel="stylesheet" type="text/css" media="all">
    <script src="../../js/owl.carousel.js"></script>
    <script>
        $(document).ready(function() {
            $("#owl-demo").owlCarousel({
                autoPlay: 3000, //Set AutoPlay to 3 seconds
                items: 5,
                itemsDesktop: [640, 4],
                itemsDesktopSmall: [414, 3]
            });
        });
    </script>
    <!-- //banner-bottom-plugin -->
    <!---<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css'>--->
    <!-- start-smoth-scrolling -->
    <script type="text/javascript" src="../../js/move-top.js"></script>
    <script type="text/javascript" src="../../js/easing.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event) {
                event.preventDefault();
                $('html,body').animate({
                    scrollTop: $(this.hash).offset().top
                }, 1000);
            });
        });
    </script>

	<!-- Facebook Pixel Code -->
	<script>
		!function(f,b,e,v,n,t,s){
			if(f.fbq)return;
			n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};
			if(!f._fbq)f._fbq=n;
			n.push=n;
			n.loaded=!0;
			n.version='2.0';
			n.queue=[];
			t=b.createElement(e);
			t.async=!0;
			t.src=v;
			s=b.getElementsByTagName(e)[0];
			s.parentNode.insertBefore(t,s)
		}(window, document,'script','https://connect.facebook.net/en_US/fbevents.js');
		fbq('init', '2806909102866217');
		fbq('track', 'PageView');
	</script>
	<noscript>
		<img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=2806909102866217&ev=PageView&noscript=1"/>
	</noscript>
	<!-- End Facebook Pixel Code -->
    <script>
    if ('serviceWorker' in navigator) {
        console.log("Will service worker register?");
        navigator.serviceWorker.register('/service-worker.js').then(function(reg){
            //console.log("Yes it did.");
            console.log('Service worker registration succeeded:', reg);
        }).catch(function(err){
            console.log("No it didn't. This happened: ",err)
        });
    }else {
      console.log('Service workers are not supported.');
    }
    
    $(function() {
        let deferredPrompt;
        const divInstall = document.getElementById('installContainer');
        const butInstall = document.getElementById('butInstall');
        
        window.addEventListener('beforeinstallprompt', (event) => {
          // 防止迷你信息栏出现在移动设备上。
          event.preventDefault();
          console.log('👍','beforeinstallprompt', event);
          //alert('beforeinstallprompt');
          // 隐藏事件，以便以后再触发。
          window.deferredPrompt = event;
          deferredPrompt = event;
          // 从安装按钮容器中删除 'hidden' 类。
          divInstall.classList.toggle('hidden', false);
        });

        window.addEventListener('appinstalled', (event) => {
          console.log('👍', 'appinstalled', event);
          // 回收 deferredPrompt 变量
          window.deferredPrompt = null;
        });
        
        //divInstall.classList.toggle('hidden', false);

        butInstall.addEventListener('click', async () => {
          console.log('👍', 'butInstall-clicked');
          const promptEvent = window.deferredPrompt;
          if (!promptEvent) {
            // 延迟提示不存在。
            //alert('延迟提示不存在')
            return;
          }
          // 显示安装提示。
          promptEvent.prompt();
          // Log the result
          const result = await promptEvent.userChoice;
          console.log('👍', 'userChoice', result);
          // 重置延迟提示变量，因为
          // prompt() 只能调用一次。
          window.deferredPrompt = null;
          // 隐藏安装按钮。
          divInstall.classList.toggle('hidden', true);
        });
        
        /*butInstall.addEventListener("click", (e) => {
            console.log('👍', 'butInstall-clicked');
            // 5. 點選後 "安裝按鈕" 隱藏 (也可以停用)
            divInstall.classList.toggle('hidden', true);
            // 6. 點選按鈕後才觸發提示視窗
            //deferredPrompt.prompt();
            const promptEvent = window.deferredPrompt;
            // 7. 等待使用者確認或拒絕
            //const result = await promptEvent.userChoice;
            promptEvent.userChoice.then((choiceResult) => {
              // 8. 從 userChoice 的結果判斷是否安裝成功
              if (choiceResult.outcome === "accepted") {
                console.log("User accepted the A2HS prompt");
              } else {
                console.log("User dismissed the A2HS prompt");
              }
              // 9. 用過就不能再用了
              window.deferredPrompt = null;
              deferredPrompt = null;
            });
        });*/
    });
    
    /*$(function() {
        let deferredPrompt;
        const addBtn = document.querySelector(".add-button");
        addBtn.style.display = "none";

        window.addEventListener("beforeinstallprompt", (e) => {
            // 2. 停用 Chrome 67 前的公版提示視窗
            e.preventDefault();
            // 3. 記得把事件存起來，後續在安裝的流程上會需要
            deferredPrompt = e;
            // 4. 讓 "安裝按鈕" 顯示
        });
        
        addBtn.style.display = "block";

        addBtn.addEventListener("click", (e) => {
            // 5. 點選後 "安裝按鈕" 隱藏 (也可以停用)
            addBtn.style.display = "none";
            // 6. 點選按鈕後才觸發提示視窗
            deferredPrompt.prompt();
            // 7. 等待使用者確認或拒絕
            deferredPrompt.userChoice.then((choiceResult) => {
              // 8. 從 userChoice 的結果判斷是否安裝成功
              if (choiceResult.outcome === "accepted") {
                console.log("User accepted the A2HS prompt");
              } else {
                console.log("User dismissed the A2HS prompt");
              }
              // 9. 用過就不能再用了
              deferredPrompt = null;
            });
        });
    });*/
    </script>
  <script type="module">
   import 'https://cdn.jsdelivr.net/npm/@pwabuilder/pwaupdate';
   const el = document.createElement('pwa-update');
   document.body.appendChild(el);
</script>
	</head>
<style>
	body {
		font-family: "PingFang TC", 微軟正黑體, sans-serif;
		background: #f6f5f7;
		background-image: url(../../images/viet/bg_login.png);
		background-size: 100%100%;
	}
	.c-title{
		position: relative;
		width: 100%;
		height: 265px;
		background-image: linear-gradient(to left,#54b5b5,#67afea);
		text-align: center;
		box-sizing: border-box;
		padding: 70px;
		overflow: hidden;
	}
	.c-title .logo img{
		margin: 5px 0 0 0;
		background-color: white;
		padding: 10px 20px;
		border-radius: 20px;
	}
	.c-title:before{
		content: '';
		display: block;
		width: 150px;
		height: 150px;
		border-radius: 100%;
		position: absolute;
		background-color: rgba(255,255,255,0.2);
		bottom: -55px;
		left: -70px;
	}
	.c-login{
		padding: 32px 0px;
		position: relative;
		margin: auto;
		box-shadow:0 0 16px 4px #c5c5c5;
		margin:0px 8%;
		margin-bottom: 20px;
		background:#fff;
	}
	.c-login h1{
		font-size: 24px;
		color: #1a2d4d;
		margin: 0;
		font-weight: bold;
		text-align: center;
	}
	.c-login h2{
		font-size: 16px;
		color: #1a2d4d;
		margin: 0px 0px 25px 34px;
		font-weight: 500;
	}
	.c-login h3{
		font-size: 14px;
		color: #1a2d4d;
		margin: 0px 0px 15px 34px;
		font-weight: 500;
		line-height: 8px;
	}
	.c-login .loginForm{
		text-align: center;
	}
	::placeholder {
		color: #979797;
		opacity: 1; /* Firefox */
	}
	:-ms-input-placeholder { /* Internet Explorer 10-11 */
		color: 979797;
	}
	::-ms-input-placeholder { /* Microsoft Edge */
		color: 979797;
	}
	.c-login .loginForm input[type="text"],.c-login select,
	.c-login .loginForm input[type="password"],
	.c-login .loginForm input[type="email"],
	.c-login .loginForm input[type="tel"],
	.c-login .loginForm input[type="button"],
	.c-login .loginForm input[type="get"]{
		display: block;
		border: none;
		box-shadow: 0 0 8px 1px #c5c5c5;
		background-color: transparent;
		width: 200px;
		margin: 0px auto 20px auto;
		font-size: 13px;
		-webkit-appearance:none;
		border-radius:0;
	}
	.c-login .loginForm input[type="text"]{
		padding: 10px 0px 10px 30px;
		background-image: url(../../images/viet/people.png);
		background-repeat: no-repeat;
		background-size: 13px;
		background-position: 6px 9px;
	}
	.c-login .loginForm input[type="text"]:focus, .c-login .loginForm input[type="password"]:focus{
		outline:none;
		border:1px solid #ff6600;
	}
	.c-login .loginForm .userPhone{
		background-image:url(../images/phone.png)!important;
		background-size: 15px!important;
		padding: 10px 0px 10px 30px;
		background-repeat: no-repeat;
		background-position: 5px 3px;
	}
	.c-login .loginForm .userRealName{
		background-image: url(../images/ID.png)!important;
		background-size: 18px!important;
	}
	.c-login .loginForm .user_communication{
		background-image: url(../images/softwareid.png)!important;
		background-size: 15px!important;
		padding: 10px 0px 10px 30px;
		background-repeat: no-repeat;
		background-position: 5px 3px;
	}
	.realname_note{
		font-size: 12px;
		color: #ff2121;
		margin: 0 auto;
		margin-left: 35px;
		margin-bottom:12px;
		text-align: left;
		width: 230px;
		margin: 0px auto 20px auto;
	}
	.c-login .loginForm input[type="password"]{
		padding: 10px 0px 10px 30px;
		background-image: url(../../images/viet/lock111.png);
		background-repeat: no-repeat;
		background-size: 13px;
		background-position: 6px 6px;
	}
	.c-login .loginForm .codeDiv{
		width: 230px;
		margin: 0px auto 20px auto;
		border-bottom: 1px solid rgb(215,215,215);
	}
	.c-login .loginForm .codeDiv input[type="text"]{
		margin: 0px;
		border: none;
	}
	.c-login .loginForm input[type="button"],
	.c-login .loginForm input[type="get"]{
		padding: 12px 0px;
		margin-bottom: 10px;
		margin-top: 25px;
		border-radius: 20px;
		width: 230px;
		color: white;
		background-color: #ff6600;
		border: 0;
		font-size: 16px;
		box-shadow: 0px 5px 10px 2px #ecba99;
		cursor: pointer;outline:none;
	}
	.c-login .loginForm input[type="button"]:hover{
		background-color:#c34f01;
	}
	.c-login .loginForm input[type="get"]:hover{
		background-color:#c34f01;
	}
	.c-login .otherBtn{
		font-size: 12px;
		text-align: center;
	}
	.c-login .otherBtn em{
		margin-left: 80px;
	}
	.c-login .otherBtn .findPwd{
		color: rgb(153,153,153);
	}
	.c-otherLogin{
		width: 100%;
		margin-top: 100px;
		margin: 100px 0px 40px 0px;
		text-align: center;
	}
	.c-otherLogin h1{
		color: rgb(153,153,153);
		font-size: 15px;
		margin-bottom: 20px;
	}
	.c-otherLogin .otherLogin {
		width: 35px;
		height: 35px;
		border: 1px solid rgb(215,215,215);
		display: inline-block;
		margin-right: 40px;
		border-radius: 50%;
		position: relative;
	}
	.c-otherLogin .otherLogin:last-child{
		margin-right: 0px;
	}
	.c-otherLogin .otherLogin img{
		width: 26px;
		position: absolute;
		top: 50%;
		left: 50%;
		margin-top: -10px;
		margin-left: -13px;
	}
	.c-login .loginForm .codeImg{
		width: 75px;
		height: 25x;
		vertical-align: middle;
	}
	.join{
		padding: 12px 0px;
		margin-bottom:10px;
		border-radius: 20px;
		width: 230px;
		color: white;
		background-color:#949494;
		border: 0;
		font-size: 16px;
		box-shadow: 0px 5px 10px 2px #ccc;
		margin: 0px auto 20px auto;
		margin-top:16px;
		display: block;
		line-height: normal;
	}
	.join:hover{
		background-color: #7d7d7d;
	}
	.c-login .loginForm .codeText{
		display: inline!important;
		background-image: url(../images/shield.png)!important;
		width: 120px !important;
	}
	.c-login .loginForm .codeBtn{
		padding: 4px 0px 4px 0px!important;
		width: 75px!important;
		display: inline!important;
		border-radius: 5px!important;
		font-size: 12px!important;
	}
	.container{
		padding:6% 0 0 0;
	}
	.logo{
		text-align: center;
		margin-bottom: 30px;
	}
	.more_icon{
		display: inline-block;
		margin: 0 5px;
	}
	.select_country{
		padding: 10px 0px 10px 30px;
		color: #bbbbbf;
		background-image: url(../images/location.png);
		background-size: 15px;
		width: 230px !important;
		background-repeat: no-repeat;
		background-position: 6px 6px;
	}
	.select_app{
		padding: 10px 0px 10px 30px;
		color: #bbbbbf;
		background-image: url(../images/software.png);
		background-size: 15px;
		width: 230px !important;
		background-repeat: no-repeat;
		background-position: 6px 9px;
	}
	.app_note{
		font-size: 14px;
		color: #48566d;
		font-weight: 500;
		margin: 0 auto;
		margin-left: 35px;
		margin-bottom:0px;
		text-align: left;
	}
	.app_note2{
		font-size: 12px;
		color: #979797;
		margin: 0 auto;
		margin-left: 35px;
		margin-bottom: 12px;
		text-align: left;
	}
	.signup_col{
		width: 49%;
		float:left;
	}
	.clear {
		clear: both;
	}
	@media only screen and (max-width:770px) {
		.signup_col {
			width: 100%;
		}
	}
</style>
<script>
    function checkeandn(f) {
        re = /^([a-zA-Z]+\d+|\d+[a-zA-Z]+)[a-zA-Z0-9]*$/;
        if (!re.test(f)) {
            return false;
        }
        return true;
    }

    function checkEmail(remail) {
        //if (remail.search(/^\w+[.a-zA-Z0-9_-]*@\w+((\.[a-zA-Z0-9_-]{2,3}){1,2})$/))!=-1) {
        if (remail.search(/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/) != -1) {
            return true;
        } else {
            return false;
        }
    }

    function doit() {
        $('#span_memId').hide();
        $('#span_passwd').hide();
        $('#span_passwd2').hide();
        $('#span_mobile').hide();
        $('#span_mobile2').hide();
        $('#span_Agree').hide();
        $('#memId').prop('readonly', true);
		//$('#codeid').prop('readonly', true);
        $('#passwd').prop('readonly', true);
        $('#passwd2').prop('readonly', true);
        $('.btn1').prop('disabled', true);
        //
        var memId = $('#memId').val();
        var passwd = $('#passwd').val();
        var passwd2 = $('#passwd2').val();
        var blank_name = $('#blank_name').val();
		//var codeid = $('#codeid').val();
        var email = $('#email').val();
        var mobile = '0900000000';//$('#mobile').val();
        var mobileauth = '12345';//$('#mobileauth').val();
        var obj = document.getElementById('country');
        var country = obj[obj.selectedIndex].value; //obj.value; //
        var qx = $('#qx').val();
        var msg = '';
        if (memId == '') {
            //$('#span_memId').html('請輸入帳號');
            //$('#span_memId').show();
            msg = msg + 'please enter account\n';
        } else if (memId.length < 6 || memId.length > 12) {
            //$('#span_memId').html('長度為6-12個字đồng');
            //$('#span_memId').show();
            msg = msg + 'account length is 6-12 characters\n';
        } else if (!checkeandn(memId)) {
            //$('#span_memId').html(' kết hợp chữ cái và số tiếng anh');
            //$('#span_memId').show();
            msg = msg + 'account must be a combination of English letters and numbers\n';
        }
        if (passwd == '') {
            //$('#span_passwd').html('請輸入密碼');
            //$('#span_passwd').show();
            msg = msg + 'please enter password\n';
        } else if (passwd.length < 6 || passwd.length > 12) {
            //$('#span_passwd').html('長度為6-12個字đồng');
            //$('#span_passwd').show();
            msg = msg + 'password length is 6-12 characters\n';
        } else if (!checkeandn(passwd)) {
            //$('#span_passwd').html(' kết hợp chữ cái và số tiếng anh');
            //$('#span_passwd').show();
            msg = msg + 'password must be a combination of English letters and numbers\n';
        } else if (memId == passwd) {
            //$('#span_passwd').html('密碼不得與帳號相同');
            //$('#span_passwd').show();
            msg = msg + 'password must not be the same as account\n';
        } else if (passwd != passwd2) {
            //$('#span_passwd').hide();
            //$('#span_passwd2').show();
            msg = msg + 'password two inputs are different\n';
        }

        if (blank_name == '') {
            //$('#span_mobile').html('請輸入手機');
            //$('#span_mobile').show();
            msg = msg + 'please enter your real name (Same as bank card)\n';
        }
		
		/*if (codeid == '') {
            //$('#span_mobile').html('請輸入手機');
            //$('#span_mobile').show();
            msg = msg + 'Please enter the số chứng minh thư nhân dân\n';
        }*/

        /*if (email == '') {
            //$('#span_mobile').html('請輸入手機');
            //$('#span_mobile').show();
            msg = msg + '請輸入E-Mail\n';
        } else if (!checkEmail(email)) {
            //$('#span_mobile').html('長度必須是10，且必需為09開頭。');
            //$('#span_mobile').show();
            msg = msg + '請輸入正確的E-Mail。\n';
        }*/

        if (mobile == '') {
            //$('#span_mobile').html('請輸入手機');
            //$('#span_mobile').show();
            msg = msg + 'please enter your phone\n';
        } else if (!mobile.match(/^09[0-9]{8}$/) && country == "tw") {
            //$('#span_mobile').html('長度必須是10，且必需為09開頭。');
            //$('#span_mobile').show();
            msg = msg + 'length must be 10 and must start with 09\n';
        }

        if (mobileauth == '') {
            //$('#span_mobile2').html('請輸入驗證碼');
            //$('#span_mobile2').show();
            msg = msg + 'please enter verification code\n';
        }
		
		var messagename = $('#messagename').val();

        if ($('#messagename').val() == "") {
            msg = msg + 'please enter communication software account\n';
        } else if( messagename.length != 10 ){
			msg = msg + 'communication software account must be 10 digits\n';
		}
		
        /*if (!$('#iAgree').is(':checked')) {
        	$('#span_Agree').show();
        	msg = '1';
        }*/

        if (msg != '') {
            $('#memId').prop('readonly', false);
            $('#passwd').prop('readonly', false);
            $('#passwd2').prop('readonly', false);
			//$('#codeid').prop('readonly', false);
            $('.btn1').prop('disabled', false);
            swal(msg);
            return;
        }
        $.blockUI();
        var system = $('#system').val();
        $.post("lib/doaction.php", {
			act: "signup",
			memId: memId,
			passwd: passwd,
			blank_name: blank_name,
			//codeid: codeid,
			qx: qx,
			mobile: mobile,
			email: email,
			mobileauth: mobileauth,
			mobilehash: $('#mobilehash').val(),
			system: system,
			country: country,
			messageapp: $('#messageapp').val(),
			messagename: $('#messagename').val(),
			authnum: $('#authnum').val(),
			uac: $('#uac').val(),
		},
		function(data, status) {
			var obj = JSON.parse(data);
			if (obj.error == "Ok") {
				//location.href = obj.url;
				//hrefDone(obj.url);
				//getApp(obj.url);
				$('#success').show();
				$('#signupstart').hide();
				$('#loginurl').val(obj.url);
				//setTimeout(function(){ readyLogin(); }, 2000);
				readyLogin(obj.nowtoken);
			} else {
				//$('#span_memId').html(obj.error_msg+' code:'+obj.error_code);
				//$('#span_memId').show();
				$.unblockUI();
				alert(obj.error_msg + ' code:' + obj.error_code);
				$('.signupbox').prop('readonly', false);
				$('.ui-btn').prop('disabled', false);
				$('#memId').prop('readonly', false);
				//$('#codeid').prop('readonly', false);
				$('#passwd').prop('readonly', false);
				$('#passwd2').prop('readonly', false);
				$('.btn1').prop('disabled', false);
			}
		});
    }

    function readyLogin(nowtoken) {
        //getApp($('#loginurl').val());
        //alert('註冊 thành công！請加入 của bạn 代理以便開通會員資格')
        //location.href='http://www.9191.com.tw/download.html';
        location.href = 'signup_done_tw.php';
    }

    function getmobileauth() {
        $('#span_mobile').hide();
        //$('#mobile').textinput('disable');
        $("#mobile").addClass("ro").attr("disabled", true);
        //$('#mobile_button').addClass('ui-disabled');
        $("#mobile_button").attr("disabled", true);
        var msg = '';
        var mobile = $('#mobile').val();

        var obj = document.getElementById('country');
        var country = obj[obj.selectedIndex].value; //obj.value; //

        if (mobile == '') {
            //$('#span_mobile').html('請輸入手機');
            //$('#span_mobile').show();
            msg = msg + 'please enter your phone\n';
        } else if (!mobile.match(/^09[0-9]{8}$/) && country == "tw") {
            //$('#span_mobile').html('長度必須是10，且必需為09開頭。');
            //$('#span_mobile').show();
            msg = msg + 'length must be 10 and must start with 09\n';
        }

        if (msg != '') {
            //$('#mobile').textinput('enable');
            $("#mobile").addClass("ro").attr("disabled", false);
            //$('#mobile_button').removeClass('ui-disabled');
            $("#mobile_button").attr("disabled", false);
            swal(msg);
            return;
        }

        $.post("lib/doaction.php", {
			act: "getmobileauth",
			mobile: mobile,
			country: country
		},
		function(data, status) {
			var obj = JSON.parse(data);
			if (obj.error == "Ok") {
				$('#mobile_button').html('SMS has been sent successfully');
				//$('#mobile').textinput('disable');
				$("#mobile").addClass("ro").attr("disabled", true);
				$('#mobilehash').val(obj.mobilehash);
				if (typeof(obj.code) != 'undefined') {
					$('#mobileauth').val(obj.code);
				}
			} else {

			}
			$('#span_mobile').hide();
		});
    }

	function check_tip(t){
		var inputvalue = $('#'+t).val();
		tip	= $('#'+t+'_tip');
		tip.attr('style','color:#ff2121');
		switch (t) {
			case "memId":
				inputvalue = $('#'+t).val();
				tip	= $('#'+t+'_tip');
				tip.attr('style','color:#ff2121');
				if(inputvalue == ''){
					tip.html('please enter account');
				}else if(inputvalue.length < 6 || inputvalue.length > 12){
					tip.html('account length is 6-12 characters');
				}else if(!checkeandn(inputvalue)){
					tip.html('account must be a combination of English letters and numbers');
				}else if(inputvalue == $('#passwd').val()){
					tip.html('account must not be the same as password');
				}else{
					tip.attr('style','color:#32CD32');
					tip.html('account format is correct');
				}
				break;
			case "passwd":
			case "passwd2":
				tip_1 = $('#passwd_tip');
				tip_2 = $('#passwd2_tip');
				inputvalue_1 = $('#passwd').val();
				inputvalue_2 = $('#passwd2').val();
				tip_1.attr('style','color:#ff2121');
				tip_2.attr('style','color:#ff2121');
				
				if(inputvalue_1 == ''){
					tip_1.html('please enter password');
				}else if(inputvalue_1.length < 6 || inputvalue_1.length > 12){
					tip_1.html('password length is 6-12 characters');
				}else if(!checkeandn(inputvalue_1)){
					tip_1.html('password must be a combination of English letters and numbers');
				}else if(inputvalue_1 == $('#memId').val()){
					tip_1.html('password must not be the same as account');
				}else{
					tip_1.attr('style','color:#32CD32');
					tip_1.html('password format is correct');
				}
				if(inputvalue_2 == ''){
					tip_2.html('please enter password again');
				}else if(inputvalue_1 != inputvalue_2){
					tip_2.html('password two inputs are different');
				}else{
					tip_2.attr('style','color:#32CD32');
					tip_2.html('password2 format is correct');
				}
				break;
			case "blank_name":
				inputvalue = $('#'+t).val();
				tip	= $('#'+t+'_tip');
				tip.attr('style','color:#ff2121');
				if(inputvalue == ''){
					tip.html('please enter bank account，for authenticate at the time of withdrawal');
				}else{
					tip.attr('style','color:#32CD32');
					tip.html('bank account entered');
				}
				break;
			case "authnum":
				inputvalue = $('#'+t).val();
				tip	= $('#'+t+'_tip');
				tip.attr('style','color:#ff2121');
				if(inputvalue == ''){
					tip.html('please enter verification code');
				}else{
					tip.attr('style','color:#32CD32');
					tip.html('verification code entered');
				}
				break;
			case "messagename":
				inputvalue = $('#'+t).val();
				tip	= $('#'+t+'_tip');
				tip.attr('style','color:#ff2121');
				if(inputvalue == ''){
					tip.html('please enter communication software account，provide corresponding agent information after applying');
				}else if(inputvalue.length != 10){
					tip.html('communication software account must be 10 digits');
				}else{
					tip.attr('style','color:#32CD32');
					tip.html('communication software account format is correct');
				}
				break;
		}
	}

    $(document).ready(function(e) {
        if (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent)) {
            //alert(navigator.userAgent);  
            //window.location.href ="iPhone.html";
            $('#system').val('ios');
            $('#ioslink').attr("href", "download.html");
        } else if (/(Android)/i.test(navigator.userAgent)) {
            //alert(navigator.userAgent); 
            //window.location.href ="Android.html";
            $('#system').val('android');
            $('#ioslink').attr("href", "javascript:alert('Please use iOS mobile phone to download');");
        } else {
            //window.location.href ="pc.html";
            $('#system').val('pc');
            $('#ioslink').attr("href", "javascript:alert('Please use iOS mobile phone to download');");
        };
        $('#system').val('ios');
    });
</script>
<script type="text/javascript" src="js/jquery.blockUI.js"></script>

<body>
    <!-- Google Tag Manager (noscript) -->
	<noscript>
		<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KH7FG9T" height="0" width="0" style="display:none;visibility:hidden"></iframe>
	</noscript>
	<!-- End Google Tag Manager (noscript) -->
    <div class="content-container scrollable ng-scope">
		<div class="container" style="overflow: hidden;">
			<div class="logo">
				<a href="index.php">
					<img src="../../images/ch/911vlogo_153x56.png" alt="911" alt="">
				</a>
			</div>
			<div class="c-login">
				<h1>Sign up</h1>
				<form action="action_Signup.php" method="post" id="frmSignup" class="loginForm">
					<input type="hidden" id="loginurl" value="">
					<input type="hidden" id="system" value="">
					<input type="hidden" id="mobilehash" value="">
					<input type="hidden" id="invite" value="vs4viet">
					<p class="result hide"></p>
					<div class="signup_col">
						<input type="hidden" name="qx" id="qx" value="vs4viet">
						<input type="hidden" name="uac" id="uac" value="">
						<input type="text" class="userLogo" id="memId" name="memId" style="margin-bottom: 5px;" oninput="check_tip(this.id);" placeholder="account">
						<p class="realname_note" id="memId_tip">please enter account</p>
						<input type="password" id="passwd" name="passwd" minlength="4" maxlength="20" style="margin-bottom: 5px;" oninput="check_tip(this.id);" placeholder="password">
						<p class="realname_note" id="passwd_tip">please enter password</p>
						<input type="password" id="passwd2" name="passwd2" minlength="4" maxlength="20" style="margin-bottom: 5px;" oninput="check_tip(this.id);" placeholder="enter password again">
						<p class="realname_note" id="passwd2_tip">please enter password again</p>
						<input type="text" class="userRealName" id="blank_name" name="blank_name" style="margin-bottom: 5px;" oninput="check_tip(this.id);" placeholder="bank account">
						<p class="realname_note" id="blank_name_tip">please enter bank account，for authenticate at the time of withdrawal</p>
						<select class="select_country" id="country" name="country" style="margin-bottom: 5px;">
							<option value="viet" selected>Region: Viet</option>
							<option value="tw">Region: Taiwan</option>
							<option value="cn">Region: Chain</option>
							<option value="hk">Region: Hongkong</option>
						</select>
					</div>
					<div class="signup_col">
						<input type="text" class="userRealName" id="authnum" name="authnum" oninput="check_tip(this.id);" style="margin-bottom: 5px;" placeholder="verification code">
						<img src="authnum.php">
						<p class="realname_note" id="authnum_tip">please enter verification code</p>
						<!--
						<input placeholder="請輸入手機號碼" id="mobile" name="mobile" type="tel" class="userPhone" minlength="10" maxlength="10" pattern="0912345678">
						<input type="text" class="codeText" placeholder="請輸入驗證碼" type="text" name="mobileauth" id="mobileauth">
						<input class="codeBtn" value="獲取驗證碼" id="mobile_button" type="get" onClick="getmobileauth()" style="text-align:center;cursor:pointer;margin-top:0;">
						-->
						<!--
						<p class="app_note">請輸入通訊軟體帳號</p>
						<p class="app_note2">申請會員後提供對應代理資訊</p>
						-->
						<select class="select_app" id="messageapp" name="messageapp" style="margin-bottom: 5px;">
							<option value="zalo" selected="selected">communication software: Zalo</option>
							<!--<option value="wechat">communication software: WeChat</option>-->     
						</select>
						<input type="text" class="user_communication" id="messagename" name="messagename" style="margin-bottom: 5px;" oninput="value=value.replace(/[^\d]/g,'');check_tip(this.id);" placeholder="communication software account">
						<p class="realname_note" id="messagename_tip">please enter communication software account，provide corresponding agent information after applying</p>
						
						<input type="button" value="Sign up" id="btnsignup" onClick="doit();">
						<a href="login.php" style="text-decoration: none;">
							<div class="join">Login</div>
						</a>
						<a href="service.php">
							<div class="more_icon">
								<img src="../../images/viet/service111.png" alt="">
							</div>
						</a>
						<a href="index.php">
							<div class="more_icon">
								<img src="../../images/viet/house111.png" alt="">
							</div>
						</a>
					</div>
					<div class="clear"></div>
				</form>
			</div>
		</div>
	</div>
</body>
</html>