 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-TW">
<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170206988-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-170206988-1');
</script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KH7FG9T');</script>
<!-- End Google Tag Manager -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="Content-Script-Type" content="text/javascript">
    <meta http-equiv="Content-Style-Type" content="text/css">
    <title>【Top Casino trực tuyến uy tín 2021】｜Trang web giải trí 911-Phục vụ 24/24｜Khuyến mãi｜CASINO｜911win-TUYÊN BỐ MIỄN TRỪ TRÁCH NHIỆM</title>
    <meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <meta HTTP-EQUIV="Cache-Control" CONTENT="no-cache">
    <meta HTTP-EQUIV="Expires" CONTENT="0">
    <meta http-equiv="Content-Language" content="zh-tw" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Trang web giải trí, bài cào Baccarat, cách chơi Baccarat, xổ số Bingo, xổ số Việt Nam VSL, thi đấu thể thao, trò chơi trực tuyến, SLOT, BBIN, S128.tặng thưởng cho lần nạp đầu tiên, nhiều ưu đãi, rút tiền miễn phí, Trang web giải trí 911, trang web giải trí uy tín, casino online uy tín, rút tiền nhanh chóng, CSKH 24/7,911win, Được công nhận là trang web giải trí tốt nhất" />
    <meta property="og:title" content="【Trang web giải trí uy tín】Trang web giải trí 911｜Bài cào Baccarat｜Trò chơi trực tuyến｜Giải đấu thể thao｜World Cup" />
    <meta property="og:keywords" content="Trang web giải trí, trang web giải trí uy tín, rút tiền nhanh chóng, LIVE CASINO, giải đấu thể tao, SLOT, trò chơi trực tuyến, xổ số, dự đoán kết quả thể thao, bóng đá, world cup, đua xe" />
    <meta itemprop="name" content="Trang web giải trí 911, Trang web giải trí tặng 700,000 cho lần nạp đầu tiên, trang web giải trí nhiều khuyến mãi, trang web giải trí được đề xuất, bài cào Baccarat, cá cược thể thao, xổ số, egames, ứng dụng rút tiền uy tín">
    <meta itemprop="keywords" content="Trang web giải trí, trang web giải trí uy tín, trang web giải trí nhiều ưu đãi, cá cược trực tuyến, bài cào Baccarat, xổ số, giải đấu thể thao, SLOT, trò chơi trực tuyến, CSKH 24/7, ứng dụng rút tiền uy tín">
    <meta name="description" itemprop="description" content="Trang web giải trí 911win tặng 700,000 khi nạp 700,000 cho lần nạp đầu tiên; Tặng 200,000 khi giới thiệu người chơi mới. CSKH hỗ trợ người chơi rút tiền 24/7. xổ số,đấu thể thao,  trò chơi trực tuyến,slot game">
    <meta name="author" content="Bài cào Baccarat, xổ số, trò chơi trực tuyến, trang web giải trí 911">
    <meta name="copyright" content="Trang web giải trí 911">
    <meta content='website' property='og:type' />
    <meta property="og:image" content="http://www.911win.co/images/ch/91logo-5.png">
    <meta property="og:url" content="http://www.911win.co" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:description" content="Trang web giải trí 911 khuyến mãi, tặng 700,000 cho lần nạp đầu, tặng phí giới thiệu cho người chơi cũ, CSKH 24/7, rút tiền nhanh chóng. Còn có nhiều hoạt động giải trí như giải đấu thể thao, bài cào Baccarat, xổ số, egames, SLOT..., vui đã đời. Chuyên nghiệp, nhanh chóng, an toàn, Trang web giải trí uy tín, trang web giải trí được đề xuất" />
    <meta name="twitter:title" content="【Trang web giải trí uy tín】｜Trang web giải trí 911-Trang web giải trí trực tuyến được bình chọn｜Khuyến mãi｜LIVE CASINO 2021" />
    <!-- Chrome, Firefox OS and Opera -->
    <meta name="theme-color" content="#222222">
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#222222">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-status-bar-style" content="#222222">
<link rel="manifest" href="manifest.json">
    <script type="application/x-javascript">
        addEventListener("load", function() {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- //for-mobile-apps -->
    <!-- banner-slider -->
    <link href="../../css/mo/jquery.slidey.min.css" rel="stylesheet">
    <!-- //banner-slider -->
    <!-- font-awesome icons -->
    <link rel="stylesheet" href="../../css/ch/font-awesome.min.css" />
    <!-- //font-awesome icons -->
    <!-- web app icon -->
    <link rel="apple-touch-icon" href="../../images/ch/icon57.png">
    <!-- 57×57px -->
    <link rel="apple-touch-icon" sizes="72×72" href="../../images/ch/icon72.png">
    <!-- 72×72px ipad-->
    <link rel="apple-touch-icon" sizes="114×114" href="../../images/ch/icon114.png">
    <!-- 114×114px iphone4-->
    <link rel="icon" sizes="192x192" href="../../images/ch/icon192.png">
    <link rel="icon" sizes="128x128" href="../../images/ch/icon128.png">
    <link rel="apple-touch-icon" sizes="128x128" href="../../images/ch/icon128.png">
    <link rel="apple-touch-icon-precomposed" sizes="128x128" href="../../images/ch/icon128.png">
    <!-- web app icon end-->
    <!-- js -->
    <script type="text/javascript" src="../../js/jquery-2.1.4.min.js"></script>
    <!-- //js -->
    
<!-- banner-bottom-plugin -->
    <link href="../../css/mo/owl.carousel.css" rel="stylesheet" type="text/css" media="all">
    <script src="../../js/owl.carousel.js"></script>
    <script>
        $(document).ready(function() {
            $("#owl-demo").owlCarousel({

                autoPlay: 3000, //Set AutoPlay to 3 seconds

                items: 5,
                itemsDesktop: [640, 4],
                itemsDesktopSmall: [414, 3]

            });

        });
    </script>
    <!-- //banner-bottom-plugin -->
    <!---<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css'>--->
    <!-- start-smoth-scrolling -->
    <script type="text/javascript" src="../../js/move-top.js"></script>
    <script type="text/javascript" src="../../js/easing.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event) {
                event.preventDefault();
                $('html,body').animate({
                    scrollTop: $(this.hash).offset().top
                }, 1000);
            });
        });
    </script>

  
<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2806909102866217');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=2806909102866217&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
<script type="module">
   import 'https://cdn.jsdelivr.net/npm/@pwabuilder/pwaupdate';
   const el = document.createElement('pwa-update');
   document.body.appendChild(el);
</script>
</head>
<style>
.content-container {margin-top:127px}.content-section{padding-top:10px;width: 100%;max-width:1200px;margin: 0 auto;}@media screen and (max-width:770px) {.content-container {margin-top: 0 !important}#outer-wp #content-wp.member dl#user-panel dt{margin-top: 32px;}#outer-wp #content-wp.member dl#user-panel dt #left{display:none}#outer-wp #content-wp.member dl#user-panel ul.cash-info{display:none;}.cashier-content .content-section{padding-top: 100px;padding-bottom: 30px;}}
body {-webkit-overflow-scrolling: touch;}
.h1,h1 {font-size: 1.1em !important;}
.top {background: #000 !important;width: 100%;height: 30px !important;}
p {margin: 0 10px !important;}
.service{background-image: url(../../images/ch/ser.png);position: fixed;right: 0%;top: 200px;width: 40px;height: 130px;z-index: 9999;cursor: pointer;display: block;}
.service:hover {background-image: url(../../images/ch/ser2.png);width: 150px;height: 246px;}
.q_title{color: #ff6600;text-align: center;margin: 15px 00;font-size: 20px;padding-bottom: 15px;border-bottom: 1px solid #ff6600;}
@media screen and (max-width:600px) {.service:hover {background-image: url(../../images/ch/ser.png);position: fixed;right: 0%;top: 200px;width: 40px;height: 130px;z-index: 9999;cursor: pointer;display: block;}}
</style>
<body>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KH7FG9T"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <!-- Messenger 洽談外掛程式 Code -->
<!--
<div id="fb-root"></div>
-->
<!-- Your 洽談外掛程式 code -->
<!--
<div id="fb-customer-chat" class="fb-customerchat"></div>
<script>
	var chatbox = document.getElementById('fb-customer-chat');
	chatbox.setAttribute("page_id", "100433372189785");
	chatbox.setAttribute("attribution", "biz_inbox");
	window.fbAsyncInit = function() {
		FB.init({
			xfbml: true,
			version: 'v12.0'
		});
	};
	(function(d, s, id) {
		var js, fjs = d.getElementsByTagName(s)[0];
		if (d.getElementById(id)) return;
		js = d.createElement(s);
		js.id = id;
		js.src = 'https://connect.facebook.net/vi_VN/sdk/xfbml.customerchat.js';
		fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));
</script>
<script type="text/javascript" src="../../js/jquery.js"></script>
<script type="application/x-javascript">
    addEventListener("load", function() {
        setTimeout(hideURLbar, 0);
    }, false);
    function hideURLbar() {
        window.scrollTo(0, 1);
    }
</script>
-->
<!-- //for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script type="text/javascript" src="../../js/jquery-2.1.4.min.js"></script>
<link href="../../css/mo/bootstrap91.css" rel="stylesheet" type="text/css" media="all" />
<link href="../../css/ch/style.css?202206141407" rel="stylesheet" type="text/css" media="all" />
<link type="text/css" rel="stylesheet" href="../../css/ch/docs.css" />
<link type="text/css" rel="stylesheet" href="../../css/ch/mmenu.css" />
<script src="../../css/ch/sweetalert.css"></script> 
<link rel="stylesheet" type="text/css" href="../../js/sweetalert.js">
<!-- js -->
<script type="text/javascript" src="../../js/jquery.mmenu.min.js"></script>
<script type="text/javascript">
    /*topbar左右選單*/
    //	The menu on the left
    $(function() {
        $('nav#menu-left').mmenu({
            searchfield: true,
            counters: true
        });
    });

    //	The menu on the right
    $(function() {
        $('nav#menu-right').mmenu({
            position: 'right',
            counters: true,
            searchfield: true
        });
        //	Click a menu-item
        var $confirm = $('#confirmation');
        $('#menu-right a').not('.mmenu-subopen').not('.mmenu-subclose').bind('click.example',function(e) {
			e.preventDefault();
			$confirm.show().text('You clicked "' + $(this).text() + '"');
			$('#menu-right').trigger('close');
		});
    });
</script>
<!-- //js -->
<script>
	if ('serviceWorker' in navigator) {
		console.log("Will service worker register?");
		navigator.serviceWorker.register('/service-worker.js').then(function(reg){
			//console.log("Yes it did.");
			console.log('Service worker registration succeeded:', reg);
		}).catch(function(err){
			console.log("No it didn't. This happened: ",err)
		});
	}else {
		console.log('Service workers are not supported.');
	}

	$(function() {
		let deferredPrompt;
		const divInstall = document.getElementById('installContainer');
		const butInstall = document.getElementById('butInstall');
		window.addEventListener('beforeinstallprompt',(event) => {
			// 防止迷你信息栏出现在移动设备上。
			event.preventDefault();
			console.log('OK','beforeinstallprompt', event);
			//alert('beforeinstallprompt');
			// 隐藏事件，以便以后再触发。
			window.deferredPrompt = event;
			deferredPrompt = event;
			// 从安装按钮容器中删除 'hidden' 类。
			//divInstall.classList.toggle('hidden', false); //<---- 暫關掉
		});

		window.addEventListener('appinstalled', (event) => {
			console.log('OK', 'appinstalled', event);
			// 回收 deferredPrompt 变量
			window.deferredPrompt = null;
		});

		//divInstall.classList.toggle('hidden', false);
		butInstall.addEventListener('click', async () => {
			console.log('OK', 'butInstall-clicked');
			const promptEvent = window.deferredPrompt;
			if (!promptEvent) {
				// 延迟提示不存在。
				//alert('延迟提示不存在')
				return;
			}
			// 显示安装提示。
			promptEvent.prompt();
			// Log the result
			const result = await promptEvent.userChoice;
			console.log('OK', 'userChoice', result);
			// 重置延迟提示变量，因为
			// prompt() 只能调用一次。
			window.deferredPrompt = null;
			// 隐藏安装按钮。
			divInstall.classList.toggle('hidden', true);
		});
	});
</script>
<!-- banner-bottom-plugin -->
<link href="../../css/mo/owl.carousel.css" rel="stylesheet" type="text/css" media="all">
<script src="../../js/owl.carousel.js"></script>
<script>
    $(document).ready(function() {
        $("#owl-demo").owlCarousel({
            autoPlay: 3000, //Set AutoPlay to 3 seconds
            items: 5,
            itemsDesktop: [640, 4],
            itemsDesktopSmall: [414, 3]
        });
    });
</script>
<link href="../../css/mo/ind2.css" rel="stylesheet" type="text/css" media="all" />
<!-- 未Đăng nhập前css -->
<!-- //banner-bottom-plugin -->
<!---<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css'>--->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="../../js/move-top.js"></script>
<script type="text/javascript" src="../../js/easing.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function($) {
        $(".scroll").click(function(event) {
            event.preventDefault();
            $('html,body').animate({
                scrollTop: $(this.hash).offset().top
            }, 1000);
        });
    });
</script>
<script type="text/javascript">
    function Login() {
        $.blockUI();
        $('#frmLogin').submit();
    }
</script>
<style>
body, div, p, span, a, ul, li, ol, strong, tr, td, th{font-family: Times New Roman, Arial, Roboto, 微軟正黑體, sans-serif;}a{color: #5b5b5b !important;} a:hover{color:#ff6600!important;}body {-webkit-overflow-scrolling: touch;}
#header {position:fixed;top:0;width:100%;-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;height: auto;background-color:#fff;background-size: cover;padding: 0 !important;box-shadow: 0px 6px 16px rgba(20%,20%,40%,0.6), 0px 8px 18px rgba(20%,20%,40%,0.4), 0px 10px 12px rgba(20%,20%,40%,0.4);}
.gray{display:flex;align-items:center;justify-content:space-between;width:100%;height:38px;padding:0 20px;background-color: #e6e6e6;}
 .dropdown span,.dropdown a{color: #282828;}.btn-drop{background: transparent;border: none;padding: 0 5px;}#drop_sub{display: none;}
 .gray_right{display: flex;justify-content:space-between;align-items: center;}.gray_right div{margin: 0 5px;}.member_ID{font-weight: bold;font-size:15px;font-family: Arial, Helvetica, Verdana;}
 .member_wallet span{color:#ff6600;}.wallet_word{margin: 0;display: inline-block;}.mail{display: flex;align-items: center;}.mail_dot{background: #ff0000;width: 10px;height: 10px;position: relative;border-radius: 50%;right: 87px;top: -7px;}
 .mail a:hover{color:#ff6600;}
 .btn_gray{background-color: #606060;color: #fff !important;border-radius:5px;padding: 3px 15px;}.btn_gray:hover{background-color:#2d2d2d;color: #fff !important;}
 .btn_orange{background-color: #ff6600;color: #fff !important;border-radius:5px;padding:3px 15px;}.btn_orange:hover{background-color:#c34f01;color: #fff !important;}
 .white_bar{padding:10px 20px;display:flex;align-items:center;justify-content:space-between;width:100%;}
.showselect {display: flex;align-items: center;justify-content: space-between;}.main-menu {color: #5b5b5b;margin:0 20px;padding:8px 0;cursor: pointer;display: inline-block;}.main-menu:hover {color: #ff6600;}
.main-menu:hover>a:after{width: 100%;left: 0;}.main-menu a:after {content: "";position: absolute;right: 0;bottom:-6px;width: 0;border-bottom: 2px solid #ff6600;transition: width .3s;}
.top_title{position: relative;}.sub-menu {width:100%;left:0;top:93px;margin-top: 0px;min-height: 100px;background-color:#fff;opacity:0.9;padding: 0px;list-style-type: none;position: absolute;}
.sub-block{display:flex;align-items:center;justify-content:center;}.game{margin:30px;}
.game:hover>a:after{width: 100%;left: 0;}.game a:after {content: "";position: absolute;right: 0;bottom:-10px;width: 0;border-bottom: 2px solid;transition: width .3s;}
.ad{display: flex;justify-content: space-between;}.ad_inner{margin: 0 15px;}.ad_inner img{transform:scale(1,1);transition: all .3s ease-out;}.ad_inner img:hover{transform:scale(1.08,1.08);}
.man{position: relative;bottom: -5px;}.tool_inner{display:flex;align-items:center;justify-content:space-between;}.tool_inner img{width: 27px;filter: invert(38%) sepia(9%) saturate(0%) hue-rotate(271deg) brightness(85%) contrast(85%);margin:0 5px;}.tool_inner img:hover{filter:unset;}
.modal {display: none;position: fixed;z-index: 1;padding-top: 100px;left: 0;top: 0;width: 100%;height: 100%;overflow: auto;background-color: rgb(0,0,0);background-color: rgba(0,0,0,0.95);}
.modal-content {background-color: transparent;margin: auto;padding: 20px;border: 0;color: #fff;width: 80%;}
.close {color: #909090;position: absolute;right: 0;top: 0;font-size: 46px;font-weight: 100;text-shadow: none;}.close:hover {color: #909090;transition:0.5s;transform: rotatey(180deg);}
#panel > ul {display:flex;align-items:center;justify-content:center;flex-direction: column;list-style: none;}.ul_inner{display: flex;align-items: center;justify-content: space-between;}
.ul_inner li{padding:25px;margin:3px;width: 160px;height: 160px;border: 1px solid rgba(220,220,220,0.4);-webkit-transform: translate3d(0,0,0);transform: translate3d(0,0,0);-webkit-transition: -webkit-transform .2s ease-in-out 0s,background .2s ease-in-out 0s;transition: transform .2s ease-in-out 0s,background .2s ease-in-out 0s;}.ul_inner li:hover{background-color:#bd4d01;opacity:0.8;cursor:pointer;}
#panel > ul > li:before {content: "";display: block;padding-top: 100%;}#panel a{position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);width: 100%;}
#panel .front {width: 100%;height: 100%;-webkit-transition: -webkit-transform .55s cubic-bezier(0.190,1.000,0.220,1.000) 0s,opacity .45s ease-in-out 0s;transition: transform .55s cubic-bezier(0.190,1.000,0.220,1.000) 0s,opacity .45s ease-in-out 0s;}.ul_inner li h3{margin:25px 0 10px 0 !important;color:#bdbdbd;font-size: 16px;font-weight:300;}.ul_inner li:hover h3{color:#fff;font-size:18px;}
.content-section4{width:100%;margin:0 auto;display:flex;justify-content:center;background: #f0f0f0;padding:0px 12%;text-align: center;}.help{border-left: 2px solid #e5e5e5;border-right: 2px solid #fff;padding: 30px 40px;text-align: center;}.help img{display: block;margin: 0 auto;padding-bottom: 10px;width: 38px;height: 45px;}.help:hover{color: #ff6600;}.help:hover img{transform:scale(1.1,1.1);}
.content-section5{width:100%;margin:0 auto;background: #7f7f7f;padding:40px 12%;text-align: center;}.content-section5_info{display:flex;justify-content:center;}.foot_more, .foot_word, .foot_view{margin: 0 20px;color:#fff;width: 33%;}.foot_more_col{margin-bottom: 10px;}.foot_more_col a{color:#fff !important;margin: 0 10px;}.foot_more_col a:hover{color:#ff6600 !important;}.content-section5_copyright{color:#fff;margin-top: 10px;}.browser img{margin: 10px;width: 45px;}.foot{}
.section2_inner a:hover .banner_pic{-webkit-filter: contrast(1.3);}.special_inner{padding: 5px 3%;}
.mobile_member > span {color:#fff;font-size:13px;padding: 4px 7px;font-weight: 300;}
.mobile_member > img{position:absolute;top: 50%;left: 50%;transform: translate(-50%,-50%);width: 15px;}
.mobile_member{display:none;position:relative;padding:0;width: 28px;height: 28px;border-radius: 50%;}input:focus{outline:none;border:1px solid #ff6600;}.back2021{display:none;}.back2021 img{width: 27px;margin: 0 5px;}
.tip {
    display: block;
    background: #f00;
    border-radius: 50%;
    width: 8px;
    height: 8px;
    right: 5px;
    top: -2px;
    position: absolute;
}
.tip2 {
    display: block;
    background: #f00;
    border-radius: 50%;
    width: 10px;
    height: 10px;
    right: 5px;
    top: -2px;
    position: absolute;
}
.tip3 {
    display: block;
    background: #f00;
    border-radius: 50%;
    width: 12px;
    height: 12px;
    left: -20px;
    top: 6%;
    position: absolute;
}

.coin_drop_btn{background: #bcbcbc;padding: 3px 6px;}
.coin_inner{display: flex!important;justify-content: space-between;}
.coin_inner span{color:#111;}
.onoffswitch {
	position: relative;
	width: 48px;
	margin: 0 0 0 5px !important;
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
}
.onoffswitch-checkbox {
    position: absolute;
    opacity: 0;
    pointer-events: none;
}
.onoffswitch-label {
    display: block; overflow: hidden; cursor: pointer;
    height: 20px; padding: 0; line-height: 20px;
    border: 2px solid #E3E3E3; border-radius: 20px;
    background-color: #FFFFFF;
    transition: background-color 0.3s ease-in;margin-bottom: 0;
}
.onoffswitch-label:before {
    content: "";
    display: block; width: 20px; margin: 0px;
    background: #FFFFFF;
    position: absolute; top: 0; bottom: 0;
    right: 26px;
    border: 2px solid #E3E3E3; border-radius: 20px;
    transition: all 0.3s ease-in 0s; 
}
.onoffswitch-checkbox:checked + .onoffswitch-label {
    background-color: #FF6600;
}
.onoffswitch-checkbox:checked + .onoffswitch-label, .onoffswitch-checkbox:checked + .onoffswitch-label:before {
	border-color: #FF6600;
}
.onoffswitch-checkbox:checked + .onoffswitch-label:before {
    right: 0px; 
}

@media only screen and (max-width:770px) {
	.back2021{display:block;}
	.gray{padding:0;}
	#unread{display:none;}
	.wallet_word{display:none;}
	.mail_dot{right:10px;}
	#welcome{display:none;}
	#member_button{display:none;}
	.showselect{display:none;}
	.white_bar{padding:3px 0px;}
	.logo_img {max-height:40px;}
	.modal-content {padding: 10px;width: 90%;}
	.close{top:-30px;}
	.front img{height:25px;max-width:30px;}
	.ul_inner li {padding:5px;width:100px;height:100px;}
	.ul_inner li h3 {margin: 12px 0 5px 0 !important;font-size:12px;}
	.ul_inner li:hover h3 {font-size:13px;}
	.game_name{font-size:13px;}
	.heart{position:unset;}
	.info_col_bottom{display:none;}
	.content-section4{padding:0px 3%;}
	.help{border-left: 1px solid #e5e5e5;border-right: 1px solid #fff;padding:8px;font-size: 12px;line-height: 18px;}
	.help img{padding-bottom: 8px;width: 22px;height: 28px;}
	.content-section5 {padding: 20px 6%;}
	.content-section5_info {flex-direction: column;}
	.foot_more, .foot_word, .foot_view {margin: 0;width: 100%;margin-bottom: 5px;}
	.browser img{width: 30px;}
	.mobile_member{display: block;}
}
.swal-overlay {z-index: 10000000000 !important;}
#installContainer {
  position: absolute;
  /*bottom: 1em;*/
  top: 0px;
  left: 0px;
  display: flex;
  justify-content: center;
  width: 20%;
  background-color:#2000E0;
}
#installContainer button {
  background-color: inherit;
  border: 1px solid white;
  color: white;
  font-size: 1em;
  padding: 0.75em;
}
.dis-n{display:none;}.dropdown-toggle::after {display:none !important;}
</style>

<body>
	<div id="installContainer" class="hidden">
		<button id="butInstall" type="button">Install</button>
	</div>
    <!-- Google Tag Manager (noscript) -->
    <noscript>
		<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KH7FG9T" height="0" width="0" style="display:none;visibility:hidden"></iframe>
	</noscript>
    <!-- End Google Tag Manager (noscript) -->
    <form id="gamefrm" method="get" action="" target="_blank"></form>
	<input type="hidden" id="islogin" value="0">
	<input type="hidden" id="rateeth" value="0">
	<input type="hidden" id="rateusdt" value="0">
	<input type="hidden" id="ratetrx" value="0">
	<div id="page">
		<div id="header">
			<div class="gray">
				<div class="gray_left">
					<div class="dropdown" id="drop_pc">
						<button type="button" class="btn-drop dropdown-toggle" id="dropdownMenu1" data-toggle="dropdown">
							<!--<img src="../../images/ch/english.png" style="width:38px" alt="">-->
							<span>English</span>
							<span class="caret"></span>
						</button>
						<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1" style="margin: 0px;left: unset !important;/*width:160px;*/width:80px;overflow: unset;min-width: unset;">
							<a role="menuitem" tabindex="-1" href="lang.php?q=viet&location=disclaimer.php" style="background: none;width: auto;display:block;text-align:center;position: unset;"><!--<img src="../../images/ch/viet.png" style="width:38px" alt="">--><span>Tiếng Việt</span></a>
							<a role="menuitem" tabindex="-1" href="lang.php?q=cn&location=disclaimer.php" style="background: none;width: auto;display:block;text-align:center;position: unset;"><!--<img src="../../images/ch/china.png" style="width:38px" alt="">--><span>简体</span></a>
							<a role="menuitem" tabindex="-1" href="lang.php?q=tw&location=disclaimer.php" style="background: none;width: auto;display:block;text-align:center;position: unset;"><!--<img src="../../images/ch/taiwan.png" style="width:38px" alt="">--><span>繁體</span></a>
							<!--<a role="menuitem" tabindex="-1" href="lang.php?q=thai&location=disclaimer.php" style="background: none;width: auto;display:block;text-align:center;position: unset;"><img src="../../images/ch/thai.png" style="width:38px" alt=""><span>ไทย(Thai)</span></a>-->
						</ul>
					</div>
				</div>
				<div class="gray_right">
										<div class="member_ID" id="welcome">Welcome</div>
					<div class="button_login_signup">
						<a href="login.php" class="btn_gray" type="button">Login</a>
						<a href="signup.php" class="btn_orange" type="button">Sign up</a>
					</div>
									</div>
			</div>
			<div class="white_bar">
				<a href="javascript:history.go(-1);" class="back2021">
					<img src="../../images/viet/back2021.svg">
				</a>
				<a href="index.php">
					<img src="../../images/ch/911vlogo_153x56.png" alt="911 Casino" class="logo_img">
				</a>
				<div class="showselect">
					<span class="main-menu">
						<a href="index.php" class="top_title">Home</a>
					</span>
					<span class="main-menu" onmouseover="switchMenu(this,'SubMenu2')" onmouseout="hideMenu()">
						<a href="game_sport.php" class="top_title">Sports</a>
						<ul id="SubMenu2" class="sub-menu" style="display:none;">
							<div class="sub-block">
								<div class="man">
									<img src="../../images/viet/man_sport.webp">
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_sport.php" class="top_title">CMD</a>
									</div>
									<div class="game">
										<a href="game_sport.php" class="top_title">UG Sports</a>
									</div>
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_sport.php" class="top_title">SABA Sports</a>
									</div>
									<div class="game">
										<a href="game_sport.php" class="top_title">IM e'SPORT</a>
									</div>
								</div>
								<!--
								<div class="ad">
									<div class="ad_inner">
										<a href="javascript:"><img src="../../images/viet/ad1.png"></a>
									</div>
									<div class="ad_inner">
										<a href="javascript:"><img src="../../images/viet/ad2.png"></a>
									</div>
								</div>
								-->
							</div>
						</ul>
					</span>
					<span class="main-menu" onmouseover="switchMenu(this,'SubMenu1')" onmouseout="hideMenu()">
						<a href="game_live.php" class="top_title">Live</a>
						<ul id="SubMenu1" class="sub-menu" style="display:none;">
							<div class="sub-block">
								<div class="game_col">
									<div class="game">
										<a href="game_live.php" class="top_title">EVO Live</a>
									</div>
									<div class="game">
										<a href="game_live.php" class="top_title">Sexy Live</a>
									</div>
									<div class="game">
										<a href="game_live.php" class="top_title">Allbet Live</a>
									</div>
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_live.php" class="top_title">Salong Live</a>
									</div>
									<div class="game">
										<a href="game_live.php" class="top_title">WM Live</a>
									</div>
									<div class="game">
										<a href="game_live.php" class="top_title">DG Live</a>
									</div>
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_live.php" class="top_title">AG Live</a>
									</div>
									<div class="game">
										<a href="game_live.php" class="top_title">XG Live</a>
									</div>
								</div>
								<!--
								<div class="ad">
									<div class="ad_inner">
										<a href="javascript:;"><img src="../../images/viet/ad1.png"></a>
									</div>
									<div class="ad_inner">
										<a href="javascript:"><img src="../../images/viet/ad2.png"></a>
									</div>
								</div>
								-->
								<div class="man">
									<img src="../../images/viet/girrl.webp">
								</div>
							</div>
						</ul>
					</span>
					<span class="main-menu" onmouseover="switchMenu( this, 'SubMenu3' )" onmouseout="hideMenu()">
						<a href="game_egame.php" class="top_title">E-games</a>
						<ul id="SubMenu3" class="sub-menu" style="display:none;">
							<div class="sub-block">
								<div class="game_col">
									<div class="game">
										<a href="game_egame.php" class="top_title">EVO E-games</a>
									</div>
									<div class="game">
										<a href="game_egame.php" class="top_title">IGSlot</a>
									</div>
									<div class="game">
										<a href="game_egame.php" class="top_title">CQ9</a>
									</div>
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_egame.php" class="top_title">V8</a>
									</div>
									<div class="game">
										<a href="game_egame.php" class="top_title">RICH</a>
									</div>
									<div class="game">
										<a href="game_egame.php" class="top_title">QTech</a>
									</div>
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_egame.php" class="top_title">BBIN Fishing</a>
									</div>
									<div class="game">
										<a href="game_egame.php" class="top_title">BBIN E-games</a>
									</div>
									<div class="game">
										<a href="game_egame.php" class="top_title">HC</a>
									</div>
								</div>
								<div class="man">
									<img src="../../images/viet/sharkk.webp">
								</div>
							</div>
						</ul>
					</span>
					<span class="main-menu" onmouseover="switchMenu( this, 'SubMenu4' )" onmouseout="hideMenu()">
						<a href="game_lottery.php" class="top_title">Lottery</a>
						<ul id="SubMenu4" class="sub-menu" style="display:none;">
							<div class="sub-block">
								<div class="man">
									<img src="../../images/viet/carcar.webp">
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_lottery.php" class="top_title">VSL Lottery</a>
									</div>
									<div class="game">
										<a href="game_lottery.php" class="top_title">BBIN Lottery</a>
									</div>
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_lottery.php" class="top_title">SC Lottery</a>
									</div>
									<div class="game">
										<a href="game_lottery.php" class="top_title">WinWin Lottery</a>
									</div>
								</div>
								<!--
								<div class="ad">
									<div class="ad_inner">
										<a href="javascript:"><img src="../../images/viet/ad1.png"></a>
									</div>
									<div class="ad_inner">
										<a href="javascript:"><img src="../../images/viet/ad2.png"></a>
									</div>
								</div>
								-->
							</div>
						</ul>
					</span>
					<span class="main-menu">
						<a href="promotion.php" class="top_title">Promotion</a>
					</span>
					<span class="main-menu">
						<a href="911vip.php" class="top_title" style="color:#ff6600 !important;">VIP</a>
					</span>
										<!--
					<span class="main-menu">
						<a href="promo_page30.php" class="top_title" style="color:#b91419 !important;">
							<img src="../../images/viet/red_bn1.png">New Year's Gift
						</a>
					</span>
					-->
					<!--
					<span class="main-menu">
						<a href="save_q.php" class="top_title">Deposit and Withdrawal Instructions</a>
					</span>
					-->
				</div>
				<div class="tool">
					<div class="tool_inner">
						<a href="service.php">
							<img src="../../images/viet/headphone.svg">
						</a>
						<a href="javascript:;" id="square_menu" style="position: relative;">
														<img src="../../images/viet/9dot.svg">
						</a>
					</div>
				</div>
			</div>
			<div id="myModal" class="modal">
				<div class="modal-content">
					<span class="close">&times;</span>
					<div id="panel">
						<ul>
							<div class="ul_inner">
								<li>
									<a href="index.php" class="pjx">
										<div class="front">
											<img src="../../images/viet/house2.png">
										</div>
										<h3>All games</h3>
									</a>
								</li>
								<li>
									<a href="promotion.php">
										<div class="front">
											<img src="../../images/viet/sale.png">
										</div>
										<h3>Promotion</h3>
									</a>
								</li>
								<li>
									<a href="notice.php">
										<div class="front">
											<img src="../../images/viet/bulletin.png">
										</div>
										<h3>Latest news</h3>
									</a>
								</li>
								<!--
								<li>
									<a href="user.php" class="gotobottom">
										<div class="front">
											<img src="../../images/viet/maintain.png">
										</div>
										<h3>維護時間</h3>
									</a>
								</li>
								-->
							</div>
							<div class="ul_inner">
								<li>
									<a href="https://www.facebook.com/911win911" target="_blank" class="gotobottom">
										<div class="front">
											<img src="../../images/viet/facebook_logos.png">
										</div>
										<h3>911 FB</h3>
									</a>
								</li>
																	
								<!--
								<li>
									<a href="https://appdn.911win.co/app/downloadapp2.php?lang=en">
										<div class="front">
											<img src="../../images/viet/APP.png">
										</div>
										<h3>Mobile shortcut download method</h3>
									</a>
								</li>
								-->
								<li>
									<a onclick="showGuide('ios')">
										<div class="front">
											<img src="../../images/viet/APP.png">
										</div>
										<h3>How to add a home screen shortcut on iOS</h3>
									</a>
								</li>
								<li>
									<a onclick="showGuide('android')">
										<div class="front">
											<img src="../../images/viet/APP.png">
										</div>
										<h3>How to add a home screen shortcut on Android</h3>
									</a>
								</li>
															</div>
																				</ul>
						<div id="mask"></div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!--手機捷徑教學 臨時擺放-->
	<style>
		.dlguide{padding-top: 100px;background:rgba(0,0,0,.8);cursor:pointer;display:none;height:100%;position:fixed;text-align:center;top:0;left:0;width:100%;z-index:10000;}.dlguide .helper{display:inline-block !important;height:100%;vertical-align:middle;background-image: none !important;}
		.dlguide > div {display: inline-block;height: auto;max-width: 551px;max-height: 800px;vertical-align: middle;width:85%;position: relative;border-radius: 8px;padding: 15px 5%;}
		.switch_btn{font-size:18px;text-shadow: none; line-height: 1.2;white-space: nowrap;text-overflow: ellipsis;font-weight: 700;cursor: pointer;background: #434756;border: none;padding: 10px 20px;text-align: center;vertical-align: middle;border-radius: 5px;color: #fff;}.switch_btn:hover{background:#5a5f72;}
		.guideCloseButton {background-color: transparent;border: 2px solid #ffac33;color: #ffac33;border-radius: 50px;cursor: pointer;display: inline-block;font-weight: bold;position: absolute;top: 5px;right: -25px;font-size: 30px;line-height: 30px;width: 35px;height: 35px;text-align: center;}
		.example{color: #20b5ff;text-decoration: underline;margin-bottom: 5px;font-size: 1.1em !important;}
		.guideCloseButton:hover {background-color: #ccc;}.mm_popup {cursor: pointer;}.mm_all{height: auto; text-align: left;}.mm_inner{padding: 20px;font-size: 16px;line-height: 22px;display:flex;border-bottom: 1px solid #ddd;}.mm_date{float: left;width:30%;text-align: center;}.mm_main{float: left;padding:0 10px;width:70%;}
		#iosPage img, #androidPage img{border-radius: 30px;box-shadow: 2px 2px 2px #ff9800, 4px 0px 6px rgb(255 152 0 / 80%), 6px 6px 12px rgb(255 152 0 / 80%);}
		@media only screen and (max-width: 770px) {.mm_all{height:400px; overflow:hidden; overflow-y:auto; -webkit-overflow-scrolling: touch;}.mm_inner {padding: 10px;font-size: 10px;}.mm_main {padding: 0 5px;}.dlguide .helper{height:70%;}
	</style>
	
	<div class="dlguide" id="iosGuide">
		<span class="helper" style="background-image: none !important;"></span>
		<div>
			<div class="guideCloseButton">X</div>
			<div class="mm_all">
				<div id="iosPage">
					<!--<img src="../../iosDownload/iosDownload_1.jpg">-->
				</div>
			</div>
			<br>
			<input class="switch_btn" type="button" onclick="backPage('ios')" value="< Prev">
            <input class="switch_btn" type="button" onclick="nextPage('ios')" value="Next >">
		</div>
	</div>
	
	<div class="dlguide" id="androidGuide">
		<span class="helper" style="background-image: none !important;"></span>
		<div>
			<div class="guideCloseButton">X</div>
			<div class="mm_all">
				<div id="androidPage">
					<!--<img src="../../androidDownload/androidDownload_1.jpg">-->
				</div>
			</div>
			<br>
			<input class="switch_btn" type="button" onclick="backPage('android')" value="< Prev">
            <input class="switch_btn" type="button" onclick="nextPage('android')" value="Next >">
		</div>
	</div>
	
	<script>
		var guidePage = 1;
		
		function showGuide(phoneType){
			guidePage = 1;
			$('#'+phoneType+'Guide').show();
			$('#'+phoneType+'Page').html('<img src="../../images/viet/' + phoneType + 'Download/' + guidePage + '.jpg" style="max-width: 100%; max-height: 100%;">');
		}
		
		function nextPage(phoneType){
			switch(phoneType){
				case 'ios':
					if(guidePage==5){
						$('#'+phoneType+'Guide').hide();
						return;
					}else{
						guidePage=guidePage+1;
					}
					break;
				case 'android':
					if(guidePage==4){
						$('#'+phoneType+'Guide').hide();
						return;
					}else{
						guidePage=guidePage+1;
					}
					break;
			}
			$('#'+phoneType +'Page').html('<img src="../../images/viet/' + phoneType + 'Download/' + guidePage + '.jpg" style="max-width: 100%; max-height: 100%;">');
		}
		
		function backPage(phoneType){
			if(guidePage==1){
				return;
			}else{
				guidePage=guidePage-1;
			}
			$('#'+phoneType+'Page').html('<img src="../../images/viet/' + phoneType + 'Download/' + guidePage + '.jpg" style="max-width: 100%; max-height: 100%;">');
		}
		
		$('.guideCloseButton').click(function(){
			$('#iosGuide').hide();
			$('#androidGuide').hide();
		});
	</script>
    <script type="text/javascript">
        var VisibleMenu = ''; // 記錄Hiện tại 顯示的子選單的 ID
        // 顯示或隱藏子選單
        function switchMenu(theMainMenu, theSubMenu, theEvent) {
            var SubMenu = document.getElementById(theSubMenu);
            if (SubMenu.style.display == 'none') { // 顯示子選單
                SubMenu.style.display = 'block';
                hideMenu(); // 隱藏子選單
                VisibleMenu = theSubMenu;
            } else { // 隱藏子選單
                if (theEvent != 'MouseOver' || VisibleMenu != theSubMenu) {
                    SubMenu.style.display = 'none';
                    VisibleMenu = '';
                }
            }
        }
        // 隱藏子選單
        function hideMenu() {
            if (VisibleMenu != '') {
                document.getElementById(VisibleMenu).style.display = 'none';
            }
            VisibleMenu = '';
        }
    </script>
    <script type="text/javascript" src="js/jquery.blockUI.js"></script>
    <script>
		var modal = document.getElementById("myModal");
		var btn = document.getElementById("square_menu");
		var span = document.getElementsByClassName("close")[0];
		btn.onclick = function() {
			modal.style.display = "block";
		}
		span.onclick = function() {
			modal.style.display = "none";
		}
		window.onclick = function(event) {
			if (event.target == modal) {
				modal.style.display = "none";
			}
		}
	</script>
	<script>
		$(document).ready(function(e) {
			setTopBalance('');
			getRate();
			window.setInterval("getRate()",60000);// 一分鐘更新
		});
		
		function setTopBalance(cur){
			$("#header_vnd").addClass("dis-n");
			$("#header_eth").addClass("dis-n");
			$("#header_trx").addClass("dis-n");
			$("#header_usdt").addClass("dis-n");
			$("#header_"+cur).removeClass("dis-n");
		}
		
		function getRate(){
			$.post("member_json4cyc.php", {
				act : 'getRate',
			},
			function(data, status) {
				var obj = JSON.parse(data);
				if (obj.code == "Ok") {
					$('#rateeth').val(obj.rateeth);
					$('#rateusdt').val(obj.rateusdt);
					$('#ratetrx').val(obj.ratetrx);
				} else {
				}
			});
		}		
	</script>
</body>    <input type="hidden" id="system" value="">
    <!-- banner -->
    <div class="content-container scrollable ng-scope">
        <div class="cashier-content content ng-scope">
            <div class="content-section" style="background: #e6e6e6;padding-bottom: 80px;">
                <div class="q_title">TUYÊN BỐ MIỄN TRỪ TRÁCH NHIỆM</div>
                <p style="color: #111;">
                    1. Trang web này chỉ cung cấp các trò chơi giải trí lành mạnh, nghiêm cấm các hội viên tham gia đánh bạc, đồng thời chỉ chấp nhận hội viên đủ 18 tuổi.<br><br>
2. Đối với một số khu vực hay quốc gia vẫn chưa quy định rõ ràng tính hợp pháp của các trang web cá cược trực tuyến hoặc đã quy định rõ ràng tham gia cá cược trực tuyến là hành vi vi phạm pháp luật, trang web của chúng tôi sẽ không chấp nhận các tài khoản đăng ký từ khu vực hoặc quốc gia đó, cũng như không tiếp nhận bất kỳ giao dịch tài chính hoặc hoạt động cá cược nào.<br><br>
3. Trang web không cho phép bất kỳ ai có hành vi sử dụng trái phép nền tảng ứng dụng tại các khu vực hoặc quốc gia này.<br><br>
4. Người dùng phải tự xác nhận xem việc tham gia các trang web cá cược trực tuyến tại khu vực hoặc quốc gia nơi bạn sinh sống có hợp pháp hay không, đồng thời hoàn toàn chịu trách nhiệm. Hội viên sử dụng dịch vụ phải tuân theo luật pháp và quy định tại địa phương, trang web sẽ không chịu trách nhiệm giải quyết mọi vi phạm của hội viên liên quan đến luật pháp.

                </p>
            </div>
        </div>
    </div>
</body>

</html>