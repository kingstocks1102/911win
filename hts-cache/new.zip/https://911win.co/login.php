 
<!DOCTYPE html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-TW">
<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170206988-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-170206988-1');
</script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KH7FG9T');</script>
<!-- End Google Tag Manager -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="Content-Script-Type" content="text/javascript">
    <meta http-equiv="Content-Style-Type" content="text/css">
    <title>911win Casino trực tuyến｜Top Casino online uy tín 2021｜Phục vụ 24/24｜Khuyến mãi｜911win-Đăng nhập</title>
    <meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <meta HTTP-EQUIV="Cache-Control" CONTENT="no-cache">
    <meta HTTP-EQUIV="Expires" CONTENT="0">
    <meta http-equiv="Content-Language" content="zh-tw" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="911win casino,Trang web giải trí, bài cào Baccarat, cách chơi Baccarat, xổ số, Bingo, xổ số Việt Nam, thi đấu thể thao, thể thao điện tử, dự đoán tỷ số, World Cup 2022, trò chơi trực tuyến, SLOT, máy đánh bạc, bài cào, Tài xỉu, Xóc Đĩa, Bầu Cua Tôm Cá, Bầu Cua Tôm Cọp, tặng thưởng cho lần nạp đầu tiên, nhiều ưu đãi, rút tiền miễn phí, Trang web giải trí 911, trang web giải trí uy tín, Crypto, tiền mã hóa, Tiền ảo, ETH, USDT, casino online uy tín, rút tiền nhanh chóng, CSKH 24/7, 911win, website casino uy tín" />
    <meta property="og:title" content="911win Casino trực tuyến｜Top Casino online uy tín 2022｜live casino｜xổ số trực tuyến｜Giải đấu thể thao｜World Cup 2022" />
    <meta property="og:keywords" content="casino online, bóng đá euro, World Cup 2022, Chơi casino trực tuyến Việt Nam, liên minh huyền thoại, LoL, LMHTesports, xổ số, đấu thể thao, chơi bài trực tuyến, đá gà, máy câu cá, bóng đá, slot game, máy đánh bạc" />
    <meta itemprop="name" content="911win Casino trực tuyến, Trang web giải trí tặng 700.000 cho lần nạp đầu tiên, trang web giải trí nhiều khuyến mãi, trang web giải trí được đề xuất, tài xỉu trực tuyến, cá cược thể thao, xổ số, egames, Thanh toán nhanh chóng, bảo mật cao">
    <meta itemprop="keywords" content="casino online, trang web giải trí uy tín, trang web giải trí nhiều ưu đãi, cá cược trực tuyến, LIVE CASINO, xổ số, cá độ bóng đá trực tuyến, SLOT, bắn cá,trò chơi trực tuyến, CSKH 24/7, ứng dụng rút tiền uy tín">
    <meta name="description" itemprop="description" content="Trang web giải trí 911 khuyến mãi, tặng 700,000 cho lần nạp đầu, CSKH 24/7, rút tiền nhanh chóng, cá độ thể thao, bài cào Baccarat, xổ số, egames, SLOT, vui đã đời. Chuyên nghiệp, nhanh chóng, an toàn, website casino uy tín, trang web giải trí được đề xuất, An toàn 100%, uy tín chất lượng ">
    <meta name="author" content="live casino, xổ số, trò chơi trực tuyến, bắn cá,trang web giải trí 911">
    <meta name="copyright" content="Trang web giải trí 911">
    <meta content="website" property="og:type" />
    <meta property="og:image" content="http://www.911win.co/images/ch/91logo-5.png">
    <meta property="og:url" content="http://www.911win.co" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:description" content="Trang web giải trí 911 khuyến mãi, tặng 700,000 cho lần nạp đầu, tặng phí giới thiệu cho người chơi cũ, CSKH 24/7, rút tiền nhanh chóng. Còn có nhiều hoạt động giải trí như giải đấu thể thao, bài cào Baccarat, xổ số, egames, SLOT..., vui đã đời. Chuyên nghiệp, nhanh chóng, an toàn, Trang web giải trí uy tín, trang web giải trí được đề xuất" />
    <meta name="twitter:title" content="【Trang web giải trí uy tín】｜911win Casino trực tuyến｜Khuyến mãi｜LIVE CASINO" />
    <!-- Chrome, Firefox OS and Opera -->
    <meta name="theme-color" content="#222222">
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#222222">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-status-bar-style" content="#222222">
<link rel="manifest" href="manifest.json">
    <script type="application/x-javascript">
        addEventListener("load", function() {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- web app icon -->
    <link rel="apple-touch-icon" href="../../images/ch/icon57.png">
    <!-- 57×57px -->
    <link rel="apple-touch-icon" sizes="72×72" href="../../images/ch/icon72.png">
    <!-- 72×72px ipad-->
    <link rel="apple-touch-icon" sizes="114×114" href="../../images/ch/icon114.png">
    <!-- 114×114px iphone4-->
    <link rel="icon" sizes="192x192" href="../../images/ch/icon192.png">
    <link rel="icon" sizes="128x128" href="../../images/ch/icon128.png">
    <link rel="apple-touch-icon" sizes="128x128" href="../../images/ch/icon128.png">
    <link rel="apple-touch-icon-precomposed" sizes="128x128" href="../../images/ch/icon128.png">
    <!-- web app icon end-->
    <!-- js -->
    <script type="text/javascript" src="../../js/jquery-2.1.4.min.js"></script>
    <!-- //js -->

    <script type="text/javascript">
        function Login2() {
            //$.blockUI();
            $('#frmLogin2').submit();
        }
		
		function GoogleLogin2() {
            //$.blockUI();
            $('#frmGoogleLogin').submit();
        }
    </script>
    <!-- //banner-bottom-plugin -->
    <!---<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css'>--->
    <!-- start-smoth-scrolling -->
    <script type="text/javascript" src="../../js/move-top.js"></script>
    <script type="text/javascript" src="../../js/easing.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event) {
                event.preventDefault();
                $('html,body').animate({
                    scrollTop: $(this.hash).offset().top
                }, 1000);
            });
        });

        function LoginInside() {
            $('#frmLoginInside').submit();
        }
    </script>
<!--Google登入用-->
<!--<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>-->
<script type="text/javascript">
	let CLIENT_ID = "307325716994-3rhn5npsg507np0ni4m6e69hacigm6hq.apps.googleusercontent.com";
	let DISCOVERY_DOCS = ["https://www.googleapis.com/discovery/v1/apis/people/v1/rest"];
</script>
<script async defer src="https://apis.google.com/js/api.js"
		onload="this.onload=function(){};GoogleClientInit()"
		onreadystatechange="if (this.readyState === 'complete') this.onload()">
</script>
<script type="text/javascript">
	function isPwa() {
		return ["fullscreen", "standalone", "minimal-ui"].some(
			(displayMode) => window.matchMedia('(display-mode: ' + displayMode + ')').matches
		);
	}
	$(function () {
		if (isPwa()) {
			$('#readyLogin_pwa').val('1');
		}
		$("#btnSignIn").on("click", function () {
			$("#content").html("");//清空顯示結果
			GoogleLogin();//Google 登入
		});
		$("#btnDisconnect").on("click", function () {
			Google_disconnect();//和Google App斷連
		});
	});

	function GoogleClientInit() {
		//官網範例寫client:auth2，但本人實測由於待會要呼叫gapi.client.init而不是gapi.auth2.init，所以給client即可
		gapi.load('client', function () {
			gapi.client.init({
				//client_id 和 scope 兩者參數必填
				clientId: CLIENT_ID,
				//scope列表參考：https://developers.google.com/people/api/rest/v1/people/get
				//"profile"是簡寫，要用完整scope名稱也可以
				scope: "profile",//"https://www.googleapis.com/auth/userinfo.profile",
				discoveryDocs: DISCOVERY_DOCS
			});


		});//end gapi.load
	}//end GoogleClientInit function
	function GoogleSignup(emailAddresses,user_id){
		$.post("lib/doaction.php", {
			act: "signupGoogle",
			emailAddresses: emailAddresses,
			user_id: user_id,
			invite: "vs4viet",
			qx: "vs4viet",
			uac: "",
			//qx: "aa11",
		},
		function(data, status) {
			var obj = JSON.parse(data);
			if (obj.error == "Ok") {
				GoogleLogin2();
			} else {
				alert(obj.error+" error_msg:"+obj.error_msg);
			}
		})
	}

	function GoogleLogin() {
		let auth2 = gapi.auth2.getAuthInstance();
		auth2.signIn().then(function (GoogleUser) {
			console.log("Google登入成功");
			let user_id = GoogleUser.getId();
			console.log(`user_id:${user_id}`);
			let AuthResponse = GoogleUser.getAuthResponse(true) ;
			let id_token = AuthResponse.id_token;
			gapi.client.people.people.get({
				'resourceName': 'people/me',
				'personFields': 'names,emailAddresses',
			}).then(function (res) {
					
					/*var TESTemailAddresses = $.map(res.result.emailAddresses, function(value, index){
						return [value];
					});*/
					
					let str = JSON.stringify(res.result);//將物件列化成string，方便顯示結果在畫面上

					$("#GooglememId").val(user_id);
					$("#GooglePassword").val(res.result.emailAddresses['0']['value']);
					
					$.post("member_json.php", {
						act: "checkmemberInfo",
						GooglememId: user_id,
						GooglePassword: res.result.emailAddresses['0']['value']
					},
					function(data, status) {
						var obj = JSON.parse(data);
						console.log(obj.code);
						console.log(obj.msg);
						if (obj.code == "signup") {
							//註冊段
							GoogleSignup(res.result.emailAddresses['0']['value'],user_id);
						} else if (obj.code=="loginin") {
							//登入段
							GoogleLogin2();
						} else {
							alert("錯誤!!".obj.msg);
						}
					});
					
					//註冊
					/*
					$.post("lib/doaction.php", {
						act: "signupGoogle",
						emailAddresses: res.result.emailAddresses['0']['value'],
						user_id: user_id,
						//qx: "aa11",
					},
					function(data, status) {
						var obj = JSON.parse(data);
						if (obj.error == "Ok") {
							 $('#content').html("註冊成功，請以Google登入！");
						} else {
							 $('#content').html("error:"+obj.error+" error_msg:"+obj.error_msg);
						}
					});*/
					
					/*$("#GooglememId").val(user_id);
					$("#GooglePassword").val(res.result.emailAddresses['0']['value']);
					
					console.log("user_id:");
					console.log(user_id);
					console.log("emailAddresses:");
					console.log(res.result.emailAddresses['0']['value']);
					GoogleLogin2();*/

			});

		},
			function (error) {
				console.log("Google登入失敗");
				console.log(error);
				alert("Đăng nhập bằng tài khoản google không thành công!!\n"+error+"Google登入失敗!!"+error);
			});

	}//end function GoogleLogin



	function Google_disconnect() {
		let auth2 = gapi.auth2.getAuthInstance(); //取得GoogleAuth物件

		auth2.disconnect().then(function () {
			console.log('User disconnect.');
		});
	}
</script>
<!--Google登入用-->
<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2806909102866217');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=2806909102866217&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
<script type="module">
   import 'https://cdn.jsdelivr.net/npm/@pwabuilder/pwaupdate';
   const el = document.createElement('pwa-update');
   document.body.appendChild(el);
</script>
</head>
<style>
body {font-family: "PingFang TC", 微軟正黑體, sans-serif;background: #f6f5f7;background-image: url(../../images/viet/bg_login.png);background-size: 100%100%;}
.c-head {
    padding: 12px 0px;
    position: absolute;
    top: 0px;
    left: 15px;
    font-size: 15px;
    font-weight: bold;
    color: white;
}

.c-head img {
    width: 12px;
}
.c-title{
    position: relative;
    width: 100%;
    height: 265px;background-image: linear-gradient(to left,#54b5b5,#67afea);
    text-align: center;
    box-sizing: border-box;
    padding: 70px;
    overflow: hidden;
}
.c-title .logo{}
.c-title .logo img{margin: 5px 0 0 0;background-color: white;padding: 10px 20px;border-radius: 20px;}
.c-title .name{
    font-size: 36px;
    color: white;
}
.c-title .name:before{
    content: '';
    display: block;
    width: 260px;
    height: 260px;
    border-radius: 100%;
    position: absolute;
    background-color: rgba(255,255,255,0.2);
    top:-85px;
    right: -85px;
}
.c-title .name:after{
    content: '';
    display: block;
    width: 180px;
    height: 180px;
    border-radius: 100%;
    position: absolute;
    background-color: rgba(255,255,255,0.2);
    top: -100px;
    right: -70px;
}
.c-title:before{
    content: '';
    display: block;
    width: 150px;
    height: 150px;
    border-radius: 100%;
    position: absolute;
    background-color: rgba(255,255,255,0.2);
    bottom: -55px;
    left: -70px;
}
.c-login{
    width: 300px;
    padding: 32px 0px;
    position: relative;
    margin: auto;box-shadow:0 0 16px 4px #c5c5c5;
    margin:0px auto;margin-bottom: 20px;
    background:#fff;
}
.c-login h1{
    font-size: 24px;
    color: #1a2d4d;
    margin: 0px 0px 0px 34px;
    font-weight: bold;
}
.c-login h2{
    font-size: 16px;
    color: #1a2d4d;
    margin: 0px 0px 25px 34px;font-weight: 500;
}
.c-login h3{
    font-size: 14px;
    color: #1a2d4d;
    margin: 0px 0px 15px 34px;font-weight: 500;
    line-height: 8px;
}
.c-login .loginForm{
    text-align: center;
}
::placeholder {
  color: #979797;
  opacity: 1; /* Firefox */
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
 color: 979797;
}

::-ms-input-placeholder { /* Microsoft Edge */
 color: 979797;
}
.c-login .loginForm input[type="text"],.c-login select,
.c-login .loginForm input[type="password"],
.c-login .loginForm input[type="email"],
.c-login .loginForm input[type="tel"],
.c-login .loginForm input[type="button"],
.c-login .loginForm input[type="get"]{
    display: block;
    border: none;
box-shadow: 0 0 8px 1px #c5c5c5;background-color: transparent;
    width: 200px;
    margin: 0px auto 20px auto;
    font-size: 13px;
    -webkit-appearance:none;
    border-radius:0;
}
.c-login .loginForm input[type="text"]{
    padding: 10px 0px 10px 30px;
    background-image:url(../../images/viet/people.png);
    background-repeat: no-repeat;
    background-size: 13px;
    background-position: 6px 9px;
}
.c-login .loginForm input[type="text"]:focus, .c-login .loginForm input[type="password"]:focus{outline:none;border:1px solid #ff6600;}
.c-login .loginForm .userPhone{
    background-image:url(../images/phone.png)!important;
    background-size: 15px!important;padding: 10px 0px 10px 30px;background-repeat: no-repeat;background-position: 5px 3px;
}
.c-login .loginForm .userRealName{
    background-image:url(../images/ID.png)!important;
    background-size: 18px!important;
}
.c-login .loginForm .user_communication{
    background-image:url(../images/softwareid.png)!important;
    background-size: 15px!important;padding: 10px 0px 10px 30px;background-repeat: no-repeat;background-position: 5px 3px;
}
.realname_note{font-size: 12px;color: #ff2121;margin: 0 auto;margin-left: 35px;margin-bottom:12px;text-align: left;}
.c-login .loginForm input[type="password"]{
    padding: 10px 0px 10px 30px;
    background-image:url(../../images/viet/lock111.png);
    background-repeat: no-repeat;
    background-size: 13px;
    background-position: 6px 6px;
}
.c-login .loginForm .codeDiv{
    width: 230px;
    margin: 0px auto 20px auto;
    border-bottom: 1px solid rgb(215,215,215);
}
.c-login .loginForm .codeDiv input[type="text"]{
    margin: 0px;
    border: none;
}
.c-login .loginForm input[type="button"],
.c-login .loginForm input[type="get"]{
    padding: 12px 0px;
    margin-bottom: 10px;
    margin-top: 25px;
    border-radius: 20px;
    width: 230px;
    color: white;
    background-color: #ff6600;
    border: 0;
    font-size: 16px;
    box-shadow: 0px 5px 10px 2px #ecba99;
    cursor: pointer;outline:none;
}
.c-login .loginForm input[type="button"]:hover{background-color:#c34f01;}.c-login .loginForm input[type="get"]:hover{background-color:#c34f01;}
.c-login .otherBtn{
    font-size: 12px;
    text-align: center;
}
.c-login .otherBtn em{
    margin-left: 80px;
}
.c-login .otherBtn .findPwd{
    color: rgb(153,153,153);
}
.c-otherLogin{
    width: 100%;
    margin-top: 100px;
    margin: 100px 0px 40px 0px;
    text-align: center;
}
.c-otherLogin h1{
    color: rgb(153,153,153);
    font-size: 15px;
    margin-bottom: 20px;
}
.c-otherLogin .otherLogin {
    width: 35px;
    height: 35px;
    border: 1px solid rgb(215,215,215);
    display: inline-block;
    margin-right: 40px;
    border-radius: 50%;
    position: relative;
}
.c-otherLogin .otherLogin:last-child{
    margin-right: 0px;
}
.c-otherLogin .otherLogin img{
    width: 26px;
    position: absolute;
    top: 50%;
    left: 50%;
    margin-top: -10px;
    margin-left: -13px;
}
.c-login .loginForm .codeImg{
    width: 75px;
    height: 25x;
    vertical-align: middle;
}
.join{padding: 12px 0px;margin-bottom:10px;border-radius: 20px;width: 230px;color: white;background-color:#949494;border: 0;font-size: 16px;box-shadow: 0px 5px 10px 2px #ccc;
margin: 0px auto 20px auto;margin-top:16px;display: block;line-height: normal;}
.join:hover{background-color: #7d7d7d;}
.c-login .loginForm .codeText{
    display: inline!important;
    background-image:url(../images/shield.png)!important;
    width: 120px !important;
}
.c-login .loginForm .codeBtn{
    padding: 4px 0px 4px 0px!important;
    width: 75px!important;
    display: inline!important;
    border-radius: 5px!important;
    font-size: 12px!important;
}
.container{padding:6% 0 0 0;}
.logo{text-align: center;margin-bottom: 30px;}
.more_icon{display: inline-block;margin: 0 5px;}
.select_country{padding: 10px 0px 10px 30px;
    color: #bbbbbf;
    background-image: url(../images/location.png);
    background-size: 15px;
    width: 230px !important;
    background-repeat: no-repeat;
    background-position: 6px 6px;}
   .select_app{padding: 10px 0px 10px 30px;
    color: #bbbbbf;
    background-image: url(../images/software.png);
    background-size: 15px;width: 230px !important;
    background-repeat: no-repeat;background-position: 6px 9px;}
.app_note{font-size: 14px;color: #48566d;font-weight: 500;margin: 0 auto;margin-left: 35px;margin-bottom:0px;text-align: left;}
.app_note2{font-size: 12px;color: #979797;margin: 0 auto;margin-left: 35px;margin-bottom: 12px;text-align: left;}.fb_join, .google_join{background-color:#4268b3;padding: 12px 0px;margin-bottom: 10px;border-radius: 20px;width:230px;color:#fff;border: 0;font-size: 16px;box-shadow:0px 5px 10px 2px #b3ccfd;margin:0px auto 20px auto;margin-top:16px;display:flex;justify-content:center;line-height: normal;}.google_join{background-color:#f5f5f5;box-shadow:0px 5px 10px 2px #ccc;color:#949494;}a{text-decoration:none;}
</style>

<body>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KH7FG9T"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
 
    <div class="content-container scrollable ng-scope">
        <div class="container" style="overflow: hidden;">
        <div class="logo">
            <a href="index.php"><img src="../../images/ch/911vlogo_153x56.png" alt="911"></a>
        </div>
        <div class="c-login">
            <h1>Đăng nhập</h1>
            <form class="loginForm" action="action_Login.php" method="post" id="frmLogin2">
                <input type="hidden" name="readyLogin_it" id="readyLogin_it" value="1656208866622554">
                <input type="hidden" name="readyLogin_auth" id="readyLogin_auth" value="db8273cd76e3ec29623a61cd98a5a2fd">
				<input type="hidden" name="readyLogin_pwa" id="readyLogin_pwa" value="0">
                <p class="result hide"></p>
                <input type="text" class="userLogo" name="memId" placeholder="Tài khoản" required>
                <input type="password" name="Password" placeholder="Mật khẩu" required>
                <input type="button" value="Đăng nhập" onClick="Login2();">
                <!--<a href="facebook_login.php"><div class="fb_join"><img src="../../images/viet/facebook.png" alt="">&nbsp;FB Đăng nhập</div></a>-->
				                <div class="google_join" id="btnSignIn"><img src="../../images/viet/GOOGLE.png" alt="">&nbsp;Google Đăng nhập</div>
				                <a href="signup.php" style="text-decoration: none;"><div class="join">Đăng ký</div></a>
                <a href="service.php"><div class="more_icon"><img src="../../images/viet/service111.png" alt=""></div></a>
                <a href="index.php"><div class="more_icon"><img src="../../images/viet/house111.png" alt=""></div></a>
            </form>
			<form action="action_GoogleLogin.php" method="post" id="frmGoogleLogin">
                <input type="hidden" name="readyLogin_it" id="readyLogin_it" value="1656208866622554">
                <input type="hidden" name="readyLogin_auth" id="readyLogin_auth" value="db8273cd76e3ec29623a61cd98a5a2fd">
                <input type="hidden" class="userLogo" name="GooglememId" id="GooglememId" placeholder="帳號" required>
                <input type="hidden" name="GooglePassword" id="GooglePassword" type="password" placeholder="密碼" required>
            </form>
        </div>
    </div>
    </div>
    
</body>

</html>