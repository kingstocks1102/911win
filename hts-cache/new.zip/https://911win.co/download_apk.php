 
<!DOCTYPE html>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-TW">

<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170206988-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-170206988-1');
</script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KH7FG9T');</script>
<!-- End Google Tag Manager -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="Content-Script-Type" content="text/javascript">
    <meta http-equiv="Content-Style-Type" content="text/css">
    <title>【Top Casino trực tuyến uy tín 2021】｜Trang web giải trí 911-Phục vụ 24/24｜Khuyến mãi｜CASINO｜911win-理查德撲 電腦Apk安裝說明</title>
    <meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <meta HTTP-EQUIV="Cache-Control" CONTENT="no-cache">
    <meta HTTP-EQUIV="Expires" CONTENT="0">
    <meta http-equiv="Content-Language" content="zh-tw" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="911Thành phố giải trí,Texas Hold'em,娛樂,911Thành phố giải trí,Thành phố giải trí">
    <script type="text/javascript" src="../../js/jquery.min.js"></script>
    <script type="application/x-javascript">
        addEventListener("load", function() {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- //for-mobile-apps -->
    <link href="../../css/mo/bootstrap91.css" rel="stylesheet" type="text/css" media="all" />
    <link href="../../css/ch/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href="../../css/ch/ind.css" rel="stylesheet" type="text/css" />
    <!-- banner-slider -->
    <link href="../../css/mo/jquery.slidey.min.css" rel="stylesheet">
    <!-- //banner-slider -->
    <!-- font-awesome icons -->
    <link rel="stylesheet" href="../../css/ch/font-awesome.min.css" />
    <!-- //font-awesome icons -->
    <!-- web app icon -->
    <link rel="apple-touch-icon" href="../../images/ch/icon57.png">
    <!-- 57×57px -->
    <link rel="apple-touch-icon" sizes="72×72" href="../../images/ch/icon72.png">
    <!-- 72×72px ipad-->
    <link rel="apple-touch-icon" sizes="114×114" href="../../images/ch/icon114.png">
    <!-- 114×114px iphone4-->
    <link rel="icon" sizes="192x192" href="../../images/ch/icon192.png">
    <link rel="icon" sizes="128x128" href="../../images/ch/icon128.png">
    <link rel="apple-touch-icon" sizes="128x128" href="../../images/ch/icon128.png">
    <link rel="apple-touch-icon-precomposed" sizes="128x128" href="../../images/ch/icon128.png">
    <!-- web app icon end-->
    <!-- js -->
    <script type="text/javascript" src="../../js/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="../../js/bootstrap.min.js"></script>
    <!-- //js -->
    
<!-- banner-bottom-plugin -->
    <link href="../../css/mo/owl.carousel.css" rel="stylesheet" type="text/css" media="all">
    <script src="../../js/owl.carousel.js"></script>
    <script>
        $(document).ready(function() {
            $("#owl-demo").owlCarousel({

                autoPlay: 3000, //Set AutoPlay to 3 seconds

                items: 5,
                itemsDesktop: [640, 4],
                itemsDesktopSmall: [414, 3]

            });

        });
    </script>
    <!-- //banner-bottom-plugin -->
    <!---<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css'>--->
    <!-- start-smoth-scrolling -->
    <script type="text/javascript" src="../../js/move-top.js"></script>
    <script type="text/javascript" src="../../js/easing.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(".scroll").click(function(event) {
                event.preventDefault();
                $('html,body').animate({
                    scrollTop: $(this.hash).offset().top
                }, 1000);
            });
        });
    </script>
    <!--GA CODE-->
    <script>
        (function(i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function() {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-102302258-1', 'auto');
        ga('send', 'pageview');
    </script>
   <!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
 fbq('init', '210618519716319'); 
fbq('track', 'PageView');
</script>
<noscript>
 <img height="1" width="1" 
src="https://www.facebook.com/tr?id=210618519716319&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->
<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '2806909102866217');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=2806909102866217&ev=PageView&noscript=1"
/></noscript>
<!-- End Facebook Pixel Code -->
<script type="module">
   import 'https://cdn.jsdelivr.net/npm/@pwabuilder/pwaupdate';
   const el = document.createElement('pwa-update');
   document.body.appendChild(el);
</script>
</head>
<style>
    .gheader-wrapper {
        width: 100%;
        position: relative;
        z-index: 5;
        background-color: #aa0000;
    }
    
    @font-face {
        font-family: "Helvetica";
        src: url(../mo/fonts/Helvetica.ttf);
    }
    
    #topnavbg {
        background-color: #fff;
        width: 100%;
        position: fixed;
        top: 0;
        z-index: 101;
    }
    
    .header {
        background-color: #e5e5e5;
    }
    
    .gheader {
        width: 950px;
        height: 100px;
        margin: 0 auto;
        padding: 0px 0 0px 0;
        position: relative;
        z-index: 1;
    }
    
    .gheader-wrapper {
        width: 100%;
        position: relative;
        z-index: 2;
        border-bottom: none;
    }
    
    .logo {
        margin: auto 0;
    }
    
    .top {
        background: #000 !important;
        width: 100%;
        height: 30px !important;
    }
    
    @media screen and (max-width:3000px) {
        .content-container {
            margin-top: 4.3em
        }
    }
    
    @media screen and (max-width:768px) {
        .content-container {
            margin-top: 4.3em
        }
    }
    
    @media screen and (max-width:728px) {
        .content-container {
            margin-top: 4.3em
        }
    }
    
    @media screen and (max-width:712px) {
        .content-container {
            margin-top: 4.3em
        }
    }
    
    @media screen and (max-width:550px) {
        .content-container {
            margin-top: 4.3em
        }
    }
    
    @media screen and (max-width:423px) {
        .content-container {
            margin-top: 4.3em
        }
    }
    
    .ios {
        border: 1px solid #a7a7a7;
        max-width: 500px;
        display: block;
        margin: 60px 0;
        width: 100%;
    }
    
    body {
        -webkit-overflow-scrolling: touch;
    }
</style>

<body>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KH7FG9T"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <script type="text/javascript" src="../../js/jquery.js"></script>
<script type="application/x-javascript">
    addEventListener("load", function() {
        setTimeout(hideURLbar, 0);
    }, false);

    function hideURLbar() {
        window.scrollTo(0, 1);
    }
</script>
<!-- //for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script type="text/javascript" src="../../js/jquery-2.1.4.min.js"></script>
<link href="../../css/mo/bootstrap91.css" rel="stylesheet" type="text/css" media="all" />
<link href="../../css/ch/style.css" rel="stylesheet" type="text/css" media="all" />
<link type="text/css" rel="stylesheet" href="../../css/ch/docs.css" />
<link type="text/css" rel="stylesheet" href="../../css/ch/mmenu.css" />
<script src="../../css/ch/sweetalert.css"></script> 
<link rel="stylesheet" type="text/css" href="../../js/sweetalert.js">
<link rel="stylesheet" href="../../css/ch/swiper.min.css">

<!-- js -->
<script type="text/javascript" src="../../js/jquery.mmenu.min.js"></script>
<script type="text/javascript">
    /*topbar左右選單*/
    //	The menu on the left
    $(function() {
        $('nav#menu-left').mmenu({
            searchfield: true,
            counters: true
        });
    });


    //	The menu on the right
    $(function() {

        $('nav#menu-right').mmenu({
            position: 'right',
            counters: true,
            searchfield: true
        });

        //	Click a menu-item
        var $confirm = $('#confirmation');
        $('#menu-right a').not('.mmenu-subopen').not('.mmenu-subclose').bind(
            'click.example',
            function(e) {
                e.preventDefault();
                $confirm.show().text('You clicked "' + $(this).text() + '"');
                $('#menu-right').trigger('close');
            }
        );
    });
</script>
<!-- //js -->

<!-- banner-bottom-plugin -->
<link href="../../css/mo/owl.carousel.css" rel="stylesheet" type="text/css" media="all">
<script src="../../js/owl.carousel.js"></script>
<script>
    $(document).ready(function() {
        $("#owl-demo").owlCarousel({

            autoPlay: 3000, //Set AutoPlay to 3 seconds

            items: 5,
            itemsDesktop: [640, 4],
            itemsDesktopSmall: [414, 3]

        });

    });
</script>
<link href="../../css/mo/ind2.css" rel="stylesheet" type="text/css" media="all" />
<!-- 未Đăng nhập前css -->
<!-- //banner-bottom-plugin -->
<!---<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css'>--->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="../../js/move-top.js"></script>
<script type="text/javascript" src="../../js/easing.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function($) {
        $(".scroll").click(function(event) {
            event.preventDefault();
            $('html,body').animate({
                scrollTop: $(this.hash).offset().top
            }, 1000);
        });
    });
</script>
<script type="text/javascript">
    function Login() {
        $.blockUI();
        $('#frmLogin').submit();
    }
</script>
<style>
    .gheader-wrapper {
        width: 100%;
        position: relative;
        z-index: 5;
        background-color: #aa0000;
    }
body, div, p{font-family: Arial, Helvetica, Verdana, sans-serif !important;}
    #topnavbg {
        background-color: #fff;
        width: 100%;
        position: fixed;
        top: 0;
        z-index: 101;
    }
    
    .header {
        background-color: #e5e5e5;
        margin: 0px;
    }
    
    .gheader {
        width: 950px;
        height: 100px;
        margin: 0 auto;
        padding: 0px 0 0px 0;
        position: relative;
        z-index: 1;
    }
.gheader-wrapper {z-index: 2;border-bottom: none;}
    #header {
        position: fixed;
        top: 0;
        width: 100%;
        -webkit-box-sizing: border-box;
        -moz-box-sizing: border-box;
        box-sizing: border-box;
        background-color: #232323;
        border-bottom: 1px solid #c6b276;
        background-size: cover;
    }
    .top_marquee{display: inline-block;float: right;margin-top: 2.5%;}
    @media only screen and (max-width: 560px) {
        #header {
            margin-top: 0px;
            margin-bottom: 0px;
        }
    }
@media only screen and (max-width: 770px) {#header {display: none}.top_marquee{display:none;}}
.mmenu li {border: none;border-top: 0px solid #444;border-bottom: 1px solid #111;}
.mmenu li>a,.mmenu li>span,.mmenu li>a:hover {color: #999;text-decoration: none;border-bottom: 1px solid #bb081b;}
.main-menu {color: #FFFFFF;padding: 5px 15px;margin: 0px;cursor: pointer;display: inline-block;}
    /* 主選單的樣式 */
.main-menu:hover {color: #ffdd77;}
.sub-menu {width: 100%;left: 0;margin-top: 0px;min-height: 100px;background-color: rgba(0, 0, 0, 0.7);padding: 0px;list-style-type: none;position: absolute;}
    /* 下拉清單的樣式 */

.sub-menu li {padding: 3px 5px;text-align: left;}
    /* 下拉清單每一列的樣式 */
.sub-menu li:hover {color: #FFFFFF;background-color: #0000FF;}
.sub-menu a {
        text-align: center;
        width: 260px !important;
        height: 100% !important;
        text-decoration: none;
        color: #FFF;
        position: unset !important;
        background: none !important;
        background-image: none !important;
        transform: translateY(0%) !important;}
    .single {
        text-align: center;
        width: 100% !important;
        height: 100% !important;
        text-decoration: none;
        color: #FFF !important;
        position: unset !important;
        background: none !important;
        background-image: none !important;
        transform: translateY(0%) !important;}
.single:hover {color: #ead38c !important;}
.showselect {margin-top: 10px;float: right;}#TopBarRight {display: block;}#TopBarRight2 {display: block;}#drop_pc{display: inline-block;margin-top:14px}#drop_pc{display: inline-block;}

@media screen and (max-width:827px) {#drop_pc{display: none;}.showselect {display: none}#TopBarRight {display: none;}}
@media screen and (min-width:770px) {#header {height: auto !important;min-height: 60px !important;}.right_open {display: none;}#TopBarRight2 {display: none;}}
.btn-blue {
        color: #ffffff !important;
        background-color: #38C0FF !important;
        border-color: #fece7a !important;
        border: 1px solid #38C0FF;
        border-radius: 6px;
        background-image: none !important;
        background: none !important;
        width: auto !important;
        position: relative !important;
        top: 0 !important;
        left: 0 !important;
        transform: none !important;
        cursor: pointer;
        display: inline-block !important;
        padding: 6px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 1.9;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
    }
    
    .btn-blue:hover {
        color: #111 !important;
        background-color: #fece7a!important;
        border-color: #fece7a !important;
        border: 1px solid #fece7a;
        border-radius: 6px;
        background-image: none !important;
        width: auto !important;
        position: relative !important;
        top: 0 !important;
        left: 0 !important;
        transform: none !important;
        cursor: pointer;
        display: inline-block !important;
        padding: 6px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 1.9;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
    }
    
    .btn-blue2 {
        color: #ffffff !important;
        background-color: #38C0FF !important;
        border-color: #fece7a !important;
        border: 1px solid #38C0FF;
        border-radius: 6px;
        background-image: none !important;
        background: none !important;
        width: auto !important;
        position: relative !important;
        top: 0 !important;
        left: 0 !important;
        transform: none !important;
        cursor: pointer;
        display: inline-block !important;
        padding: 6px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 1.9;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
    }
    
    .btn-blue2:hover {
        color: #111 !important;
        background-color: #fece7a!important;
        border-color: #fece7a !important;
        border: 1px solid #fece7a;
        border-radius: 6px;
        background-image: none !important;
        width: auto !important;
        position: relative !important;
        top: 0 !important;
        left: 0 !important;
        transform: none !important;
        cursor: pointer;
        display: inline-block !important;
        padding: 6px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 1.9;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
    }
    
    .btn-blue3 {
        color: #111 !important;
        background-color: #fece7a!important;
        border-color: #fece7a !important;
        border: 1px solid #fece7a;
        border-radius: 6px;
        background-image: none !important;
        width: auto !important;
        position: relative !important;
        top: 0 !important;
        left: 0 !important;
        transform: none !important;
        cursor: pointer;
        display: inline-block !important;
        padding: 6px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 1.9;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
    }
    
    .btn-blue3:hover {
        color: #ffffff !important;
        background-color: #38C0FF !important;
        border-color: #fece7a !important;
        border: 1px solid #fece7a;
        border-radius: 6px;
        background-image: none !important;
        background: none !important;
        width: auto !important;
        position: relative !important;
        top: 0 !important;
        left: 0 !important;
        transform: none !important;
        cursor: pointer;
        display: inline-block !important;
        padding: 6px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 1.9;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
    }
    .btn-blue4 {
        color: #ffffff !important;
        background-color: #38C0FF !important;
        border-color: #fece7a !important;
        border: 1px solid #38C0FF;
        border-radius: 6px;
        background-image: none !important;
        background: none !important;
        width: auto !important;
        position: relative !important;
        top: 0 !important;
        left: 0 !important;
        transform: none !important;
        cursor: pointer;
        display: inline-block !important;
        padding: 6px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 1.9;
        text-align: center;
        white-space: nowrap;
        margin-top:-60px !important;
        vertical-align: middle;
    }
    
    .btn-blue4:hover {
        color: #111 !important;
        background-color: #fece7a!important;
        border-color: #fece7a !important;
        border: 1px solid #fece7a;
        border-radius: 6px;
        background-image: none !important;
        width: auto !important;
        position: relative !important;
        top: 0 !important;
        left: 0 !important;
        transform: none !important;
        cursor: pointer;
        display: inline-block !important;
        padding: 6px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 1.9;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
    }
    .btn-blue5 {
        color: #ffffff !important;
        background-color: #38C0FF !important;
        border-color: #fece7a !important;
        border: 1px solid #38C0FF;
        border-radius: 6px;
        background-image: none !important;
        background: none !important;
        width: auto !important;
        position: relative !important;
        top: 0 !important;
        left: 0 !important;
        transform: none !important;
        cursor: pointer;
        display: inline-block !important;
        padding: 6px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 1.9;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
    }
    
    .btn-blue5:hover {
        color: #fff !important;
        background-color: #537CD6!important;
        border-color: #3b5998 !important;
        border: 1px solid #3b5998;
        border-radius: 6px;
        background-image: none !important;
        width: auto !important;
        position: relative !important;
        top: 0 !important;
        left: 0 !important;
        transform: none !important;
        cursor: pointer;
        display: inline-block !important;
        padding: 6px;
        margin-bottom: 0;
        font-size: 14px;
        font-weight: normal;
        line-height: 1.9;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
    }
    @-moz-keyframes move {
  0% {
    transform: translateY(-5px);
  }
  100% {
    transform: translateY(5px);
  }
}

@-webkit-keyframes move {
  0% {
    transform: translateY(-5px);
  }
  100% {
    transform: translateY(5px);
  }
}

@-o-keyframes move {
  0% {
    transform: translateY(-5px);
  }
  100% {
    transform: translateY(5px);
  }
}

@keyframes move {
  0% {
    transform: translateY(-5px);
  }
  100% {
    transform: translateY(5px);
  }
}
.top_img{width: 42px;display: block;margin: 0 auto;margin-bottom: 5px;}.top_img:hover{  animation: move .5s ease-in-out -.25s infinite alternate; -webkit-filter: sepia(1); }.scrolled{display: none;transition: 0.3s;}.btn4_scrolled{margin-top:0 !important;}
.swiper-container {width: 68%;height: 100%;float: right;margin-right: 25px;display: block;}
    .swiper-slide {
      text-align: center;
      font-size: 1em;background: transparent;
      /* Center slide text vertically */
      display: -webkit-box;
      display: -ms-flexbox;
      display: -webkit-flex;
      display: flex;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      -webkit-justify-content: center;
      justify-content: center;
      -webkit-box-align: center;
      -ms-flex-align: center;
      -webkit-align-items: center;
      align-items: center;color: #d0d0d0;
    }.sw{padding: 5px;color: #d0d0d0;}
.swiper-slide:hover .sw{color: #ffdd77;border-bottom: 3px solid #fece7a;}.swiper-slide:active .sw{color: #ffdd77;border-bottom: 3px solid #fece7a;}
.sl{background: none !important;position: unset !important;width: auto !important;left: unset !important;height: 56px !important;}.logo{float:left;}.logo_scroll{height: 70px}.marquee_scroll{    margin-top:1.4% !important;}.logo img {min-height:60px !important;display: none;}.btn-drop{background: transparent;border: 1px solid #9a9a9a;border-radius: 5px;padding: 0 5px;}#drop_sub{display: none;}
@media screen and (min-width:770px) {.logo img {min-height: 70px !important;display: inline-block;}.swiper-container {display: none;}}
</style>

<body>
    <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KH7FG9T"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <form id="gamefrm" method="get" action="" target="_blank">
    </form>
    <input type="hidden" id="islogin" value="0">
    <div id="page">
        <div id="header">
            <!--電腦  Điện thoại di động Đăng nhập前topbar -->
            <!-- Swiper -->
  <!--<div class="swiper-container">
    <div class="swiper-wrapper">
      <div class="swiper-slide"><a href="signup.php" class="sl"><div class="sw">Đăng ký miễn phí</div></a></div>
      <div class="swiper-slide"><a href="promo_page16.php" class="sl"><div class="sw">Khoản tiền thưởng tiết kiệm đầu tiên</div></a></div>
      <div class="swiper-slide"><a href="promo_page12.php" class="sl"><div class="sw"><img src="../../images/ch/govip.png" alt="" width="100%"></div></a></div>
      <div class="swiper-slide"><a href="promo_page20.php" class="sl"><div class="sw">德撲圈</div></a></div>
    </div>
  </div>-->

            <!--<ul id="TopBarRight2" style="right:0;float: right;margin: 0 auto;margin-right: 40px;margin-top:5px !important;right:0 !important;">
                               <a class="btn-blue" type="button" href="login.php">Đăng nhập</a>
                <a href="signup.php" class="btn-blue2" type="button">Đăng ký</a> </ul>-->
            <!--end-->
            <!--<div class="right_open">
                <a href="#menu-right" class="friends right"></a>
            </div>
            <nav id="menu-right">
                <ul>
                    <li>
                        <a href="settings.php"><img src="../../images/ch/spo.png" alt="" style="margin: 0 5px;">Sảnh trò chơi</a>
                    </li>
                    <li>
                        <a href="promotion.php"><img src="../../images/ch/che.png" alt="" style="margin: 0 5px;">Khuyến mãi</a>
                    </li>
                    <li>
                        <a href="https://www.abgapp88.net/" target="_blank" style="margin: 0 5px;">歐博APP下載</a>
                    </li>
                                    </ul>
            </nav>-->
            <!-- 右側打開結束-->
            <!-- Đăng nhập前顯示 -->
            <a href="index.php" class="logo"><img src="../../images/ch/91logo-5.png" alt="911Thành phố giải trí" style="margin-top:0px;height:100%;"></a>
            <!--  Điện thoại di động版顯示 -->
            <!--<div class="main_pages_top">
                <div class="pull-left">
                    <a href="login.php"><img src="../../images/ch/left_arrow.svg" alt="" style="height:25px;"></a>
                </div>
                <span class="head_title">Đăng ký</span>
                <div class="pull-right">
                    <a class="service2" href="service.php"><img src="../../images/ch/icon_service2.png"></a>
                </div>
            </div>--><!--  Điện thoại di động版顯示 end-->
            <!--            <ul id="TopBarRight" class="nav navbar-nav navbar-right" style="right:0;margin:0 auto;margin-top:5px !important;right:0 !important;">
                <form action="action_Login.php" method="post" id="frmLogin" class="form-inline" style="float: right;display: block;">
                    <input type="hidden" name="readyLogin_it" id="readyLogin_it" value="1656209301412478">
                    <input type="hidden" name="readyLogin_auth" id="readyLogin_auth" value="61d87eebd3716b374cfa46cf512a528d">
                    <p class="result hide"></p>
                    <div class="form-group">
                        <a href="forgot_password.php" style="color: #969696;background-image: none !important;color: #cccccc;background-color: transparent;border-color:transparent;background:none;width:auto;position:relative;top:0;left:0;transform:none;display: inline-block;padding: 6px;margin-bottom: 0;font-size: 14px;font-weight: normal;line-height: 1.9;text-align: center; white-space: nowrap;vertical-align: middle;">
									  Quên mật khẩu？
								  </a>
                    </div>
                    <div class="form-group" style="display: inline-block;">
                        <input name="memId" class="form-control topInput empty" type="text" placeholder="Tài khoản" required>
                    </div>
                    <div class="form-group">
                        <input name="Password" class="form-control topInput empty" type="password" placeholder="Mật khẩu" required>
                    </div>
                    <a class="btn-blue" type="button" onClick="Login();">Đăng nhập</a>
                    <a href="signup.php" class="btn-blue2" type="button">Đăng ký</a>
                </form>
            </ul>-->
            <!-- Đăng nhập前顯示結束 -->
            <!--選單(Hover+Click)-->
            <div class="showselect">
                <span class="main-menu"><a href="save_q.php" class="single"><img src="../../images/ch/q_icon.png" alt="" class="top_img">Chú ý nạp rút tiền</a></span>
                <span class="main-menu"><a href="settings.php" class="single"><img src="../../images/ch/game_hall.png" alt="" class="top_img">Sảnh trò chơi</a></span>
                <!--<span class="main-menu"><a href="video.php" class="single">影音館</a></span>-->
                <span class="main-menu"><a href="promotion.php" class="single"><img src="../../images/ch/speaker_gray.png" alt="" class="top_img">Khuyến mãi</a></span>
                <!--<span class="main-menu"><a href="service.php" class="single">Trung tâm chăm sóc khách hàng</a></span>-->
                                <a href="login.php" class="btn-blue4" type="button"><span class="logout_btn">Login</span></a>
                <a href="signup.php" class="btn-blue4" type="button"><span class="logout_btn">Signup</span></a>
                                <!--語言切換-->
                    <div class="dropdown" style="width:160px;float:right;line-height:40px;" id="drop_pc">
                    <button type="button" class="btn-drop dropdown-toggle" id="dropdownMenu1" data-toggle="dropdown">
                        <!--<img src="../../images/ch/viet.png" style="width:38px" alt="">-->
                        <span style="color: #fff;">Tiếng việt(Vietnam)</span>
                        <span class="caret" style="color: #fff;"></span>
                    </button>
                    <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1" style="margin: 0px;left: unset !important;width:160px;overflow: unset;min-width: unset;">
                        <a role="menuitem" tabindex="-1" href="lang.php?q=tw&location=download_apk.php" style="background: none;width: auto;display:block;text-align:center;position: unset;"><!--<img src="../../images/ch/taiwan.png" style="width:38px" alt="">--><span style="color: #111;">Chinese(Traditional)</span></a>
                        <a role="menuitem" tabindex="-1" href="lang.php?q=cn&location=download_apk.php" style="background: none;width: auto;display:block;text-align:center;position: unset;"><!--<img src="../../images/ch/china.png" style="width:38px" alt="">--><span style="color: #111;">Chinese(Simplified)</span></a>
                        <a role="menuitem" tabindex="-1" href="lang.php?q=en&location=download_apk.php" style="background: none;width: auto;display:block;text-align:center;position: unset;"><!--<img src="../../images/ch/english.png" style="width:38px" alt="">--><span style="color: #111;">English</span></a>
                        <a role="menuitem" tabindex="-1" href="lang.php?q=thai&location=download_apk.php" style="background: none;width: auto;display:block;text-align:center;position: unset;"><!--<img src="../../images/ch/thai.png" style="width:38px" alt="">--><span style="color: #111;">ไทย(Thai)</span></a>
                    </ul>
                </div>
            </div>
            <!-- 跑馬燈 -->
            <div class="top_marquee">
                <a href="notice.php" style="width: 100%;">
                    <img src="../../images/ch/loud.svg" style="width: 20px;margin-bottom:15px;margin-right:8px;">
                    <marquee direction="left" height="20" scrollamount="5" behavior="scroll" loop="-1" style="color: #fff;width:380px;font-size: initial;height: 100%;">
                                        </marquee>
                </a>
            </div>
                <!-- 跑馬燈結束 -->
        </div>

    </div>
    <!-- //header -->

    <!-- //Latest-tv-series -->
    <script type="text/javascript">
        var VisibleMenu = ''; // 記錄Hiện tại 顯示的子選單的 ID

        // 顯示或隱藏子選單
        function switchMenu(theMainMenu, theSubMenu, theEvent) {
            var SubMenu = document.getElementById(theSubMenu);
            if (SubMenu.style.display == 'none') { // 顯示子選單
                SubMenu.style.display = 'block';
                hideMenu(); // 隱藏子選單
                VisibleMenu = theSubMenu;
            } else { // 隱藏子選單
                if (theEvent != 'MouseOver' || VisibleMenu != theSubMenu) {
                    SubMenu.style.display = 'none';
                    VisibleMenu = '';
                }
            }
        }

        // 隱藏子選單
        function hideMenu() {
            if (VisibleMenu != '') {
                document.getElementById(VisibleMenu).style.display = 'none';
            }
            VisibleMenu = '';
        }
    </script>

    <!--Tài khoản chính點數-->
    <script type="text/javascript" src="js/jquery.blockUI.js"></script>
    <!--topbar選單圖片捲動縮起-->
    <script>
        $(function() {
    var header = $(".top_img");
    $(window).scroll(function() {    
        var scroll = $(window).scrollTop();
        if (scroll >= 50) {
            header.addClass("scrolled");
        } else {
            header.removeClass("scrolled");
        }
    });
  
});
    </script>
    <script>
        $(function() {
    var header = $(".logo");
  
    $(window).scroll(function() {    
        var scroll = $(window).scrollTop();
        if (scroll >= 50) {
            header.addClass("logo_scroll");
        } else {
            header.removeClass("logo_scroll");
        }
    });
  
});
    </script>
    <script>
        $(function() {
    var header = $(".top_marquee");
  
    $(window).scroll(function() {    
        var scroll = $(window).scrollTop();
        if (scroll >= 50) {
            header.addClass("marquee_scroll");
        } else {
            header.removeClass("marquee_scroll");
        }
    });
  
});
    </script>
    <!--topbarĐăng xuất按鈕margin捲動縮起-->
    <script>
        $(function() {
    var header = $(".btn-blue4");
  
    $(window).scroll(function() {    
        var scroll = $(window).scrollTop();
        if (scroll >= 50) {
            header.addClass("btn4_scrolled");
        } else {
            header.removeClass("btn4_scrolled");
        }
    });
  
});
    </script>
    <script>
        $(function() {
    var header = $("#drop_pc");
  
    $(window).scroll(function() {    
        var scroll = $(window).scrollTop();
        if (scroll >= 50) {
            header.addClass("btn4_scrolled");
        } else {
            header.removeClass("btn4_scrolled");
        }
    });
  
});
    </script>
<!-- Swiper JS -->
  <script src="../../js/swiper.min.js"></script>

  <!-- Initialize Swiper -->
  <script>
    var swiper = new Swiper('.swiper-container', {
      slidesPerView: 3.2,
      spaceBetween: 1,
      freeMode: true,
      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
    });
  </script>
</body>
    <!-- banner -->
    <div class="content-container scrollable ng-scope">
        <div class="casinogames-content content ng-scope">
            <h1 class="content-title ng-binding">理查德撲-電腦Apk 安裝說明</h1>
            <div class="content-section">
                <!-- ngRepeat: (filter, properties) in filters -->
                <div class="filter-container ng-scope active" ng-repeat="(filter, properties) in filters" ng-class="{'active' : properties.visible}">
                    <!-- ngIf: properties.visible -->
                    <ul ng-if="properties.visible" class="filter-game-list clearfix ng-scope">
                        <div align="center">
                            <h1 style="font-size: 22px;">安裝說明</h1>
                        </div>
                        <p style="color:#d20000">1.點選下方按鈕，進行下載</p><br>
                        <a href="http://dafuvip.com/RPoker" target="_blank">
                            <input class="button ng-scope" type="button" value="下載理查德撲-電腦Apk" style="max-width: 500px;background-color: #87560a;"></a>
                        <br>
                        <p style="color:#d20000">2.使用 Điện thoại di động模擬器，即可安裝<br><span style="color:black;">推薦軟體:&nbsp;</span><a href="http://www.bluestacks.cn/" target="_blank"><span style="color:blue;text-decoration:underline;">BleuStacks</span></a></p>
                        <div align="center">
                            <img src="../../images/ch/apkk.jpg" alt="" class="ios"></div>

                        <!-- ngRepeat: game in getFilterData(filter) -->

                    </ul>
                    <!-- end ngIf: properties.visible -->
                </div>
                <!-- end ngRepeat: (filter, properties) in filters -->
            </div>
            <div class="content-footer-new">
                <a ui-sref="settings" href="index.php"><img src="../../images/ch/back.png" alt=""> <span class="ng-binding">回Trang đầu</span></a>
            </div>

        </div>
    </div>

    <!-- //general -->

    <!-- pop-up-box -->
    <script src="../../js/jquery.magnific-popup.js" type="text/javascript"></script>
    <!--//pop-up-box -->
    <div id="small-dialog" class="mfp-hide">
        <!---<iframe src="https://player.vimeo.com/video/164819130?title=0&byline=0"></iframe>--->
    </div>
    <div id="small-dialog1" class="mfp-hide">
        <!---<iframe src="https://player.vimeo.com/video/148284736"></iframe>--->
    </div>
    <div id="small-dialog2" class="mfp-hide">
        <!---<iframe src="https://player.vimeo.com/video/165197924?color=ffffff&title=0&byline=0&portrait=0"></iframe>--->
    </div>
    <script>
        $(document).ready(function() {
            $('.w3_play_icon,.w3_play_icon1,.w3_play_icon2').magnificPopup({
                type: 'inline',
                fixedContentPos: false,
                fixedBgPos: true,
                overflowY: 'auto',
                closeBtnInside: true,
                preloader: false,
                midClick: true,
                removalDelay: 300,
                mainClass: 'my-mfp-zoom-in'
            });

        });
    </script>
    <!-- //Latest-tv-series -->

    <!-- 頁尾與上方導覽列 -->

    <!-- Bootstrap Core JavaScript -->
    <script src="../../js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $(".dropdown").hover(
                function() {
                    $('.dropdown-menu', this).stop(true, true).slideDown("fast");
                    $(this).toggleClass('open');
                },
                function() {
                    $('.dropdown-menu', this).stop(true, true).slideUp("fast");
                    $(this).toggleClass('open');
                }
            );
        });
    </script>
    <!-- //Bootstrap Core JavaScript -->
    <!-- here stars scrolling icon -->
    <script type="text/javascript">
        $(document).ready(function() {
            /*
            	var defaults = {
            	containerID: 'toTop', // fading element id
            	containerHoverID: 'toTopHover', // fading element hover id
            	scrollSpeed: 1200,
            	easingType: 'linear' 
            	};
            */

            $().UItoTop({
                easingType: 'easeOutQuart'
            });

        });
    </script>
    <script>
        $(document).ready(function() {
            $(".nav-tabs a").click(function() {
                $(this).tab('show');
            });
        });
    </script>
    <!-- //here ends scrolling icon -->
    <!-- 頁尾與上方導覽列 -->
    <!--Chăm sóc khách hàng代碼-->
    <script>
        (function() {
            var c = document.createElement("script"),
                s = document.getElementsByTagName("script")[0];
            c.src = "//kefu.qycn.com/vclient/state.php?webid=127256";
            s.parentNode.insertBefore(c, s);
        })();
    </script>
</body>

</html>