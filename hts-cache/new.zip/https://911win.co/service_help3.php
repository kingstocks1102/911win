 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-TW">
<head>
    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-170206988-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-170206988-1');
</script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KH7FG9T');</script>
<!-- End Google Tag Manager -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="Content-Script-Type" content="text/javascript">
    <meta http-equiv="Content-Style-Type" content="text/css">
    <title>911 Casino | Most people play online games, live video, baccarat, sapphire, bingo planet, cypress slot, super eight, fruit plate, little Mary, slot machine, mahjong, Texas Hold'em!-Common problem</title>
    <meta HTTP-EQUIV="Pragma" CONTENT="no-cache">
    <meta HTTP-EQUIV="Cache-Control" CONTENT="no-cache">
    <meta HTTP-EQUIV="Expires" CONTENT="0">
    <meta http-equiv="Content-Language" content="zh-tw" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="911win casino, 911win, casino, online casino, bet, baccarat, live baccarat, online bet, slots, bonus, World Cup 2022, Esports, E-games, poker, holdem, video poker, roulette, crypto, ETH, USDT, Evolution" />
    <meta property="og:title" content="911win Casino│Online casino│Baccarat│Poker online│Roulette" />
    <meta property="og:keywords" content="casino, football Euro, World Cup 2022, FIFA, LoL, lottery, Esports, sports, poker online, slots, slot game" />
    <meta itemprop="name" content="911win Casino sign up, bonus, first deposit, 100% deposit bonus, baccarat recommended, bacarrat betting">
    <meta itemprop="keywords" content="online casino, gambling, bet, baccarat casino, macau baccarat ,best casino online, online betting">
    <meta name="description" itemprop="description" content="911win Casino sign up, first deposit, 100% deposit bonus, casino online recommended, baccarat, betting online, sports betting, E-games, lottery games, the best casino">
    <meta name="author" content="baccarat, Sports betting, slot game, slots, 911win Casino">
    <meta name="copyright" content="baccarat, holdem, poker game, 911win Casino">
    <meta content='website' property='og:type' />
    <meta property="og:image" content="http://www.911win.co/images/ch/91logo-5.png">
    <meta property="og:url" content="http://www.911win.co" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:description" content="Trang web giải trí 911 Promotion, tặng 700,000 cho lần nạp đầu, tặng thưởng cho Novice, tặng phí giới thiệu cho người chơi cũ, CSKH 24/7, Withdrawal now chóng. Còn có nhiều hoạt động giải trí như giải đấu Sports, bài cào Baccarat, Lottery, egames, SLOT..., vui đã đời. Chuyên nghiệp, nhanh chóng, an toàn, 911 Casino, trang web giải trí được đề xuất" />
    <meta name="twitter:title" content="【911 Casino】｜Trang web giải trí 911-Trang web giải trí trực tuyến được bình chọn｜Promotion｜LIVE CASINO 2021" />
<!-- Chrome, Firefox OS and Opera -->
<meta name="theme-color" content="#222222">
<!-- Windows Phone -->
<meta name="msapplication-navbutton-color" content="#222222">
<!-- iOS Safari -->
<meta name="apple-mobile-web-app-status-bar-style" content="#222222">
<link rel="manifest" href="manifest.json">
<script type="application/x-javascript">
    addEventListener("load", function() {
        setTimeout(hideURLbar, 0);
    }, false);

    function hideURLbar() {
        window.scrollTo(0, 1);
    }
</script>
<!-- //for-mobile-apps -->
<link href="../../css/mo/bootstrap91.css" rel="stylesheet" type="text/css" media="all" />
<link href="../../css/ch/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="../../css/ch/style_n.css?200805" rel="stylesheet" type="text/css" media="all" />
<link href="../../css/ch/ind.css" rel="stylesheet" type="text/css" />
<link href="../../css/ch/custom.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../../js/sweetalert.min.js"></script>
<link href="../../css/ch/app.css" rel="stylesheet" type="text/css" />
<!-- banner-slider -->
<link href="../../css/mo/jquery.slidey.min.css" rel="stylesheet">
<!-- //banner-slider -->
<!-- font-awesome icons -->
<link rel="stylesheet" href="../../css/ch/font-awesome.min.css" />
<!-- //font-awesome icons -->
<!-- web app icon -->
<link rel="apple-touch-icon" href="../../images/viet/icon57.png">
<!-- 57×57px -->
<link rel="apple-touch-icon" sizes="72×72" href="../../images/viet/icon72.png">
<!-- 72×72px ipad-->
<link rel="apple-touch-icon" sizes="114×114" href="../../images/viet/icon114.png">
<!-- 114×114px iphone4-->
<link rel="icon" sizes="192x192" href="../../images/viet/icon192.png">
<link rel="icon" sizes="128x128" href="../../images/viet/icon128.png">
<link rel="apple-touch-icon" sizes="128x128" href="../../images/viet/icon128.png">
<link rel="apple-touch-icon-precomposed" sizes="128x128" href="../../images/viet/icon128.png">
<!-- web app icon end-->
<!-- js -->
<script type="text/javascript" src="../../js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="../../js/wow.min.js"></script>
<!-- //js -->

<!-- banner-bottom-plugin -->
<link href="../../css/mo/owl.carousel.css" rel="stylesheet" type="text/css" media="all">
<script src="../../js/owl.carousel.js"></script>
<script>
    $(document).ready(function() {
        $("#owl-demo").owlCarousel({

                autoPlay: 3000, //Set AutoPlay to 3 seconds

                items: 5,
                itemsDesktop: [640, 4],
                itemsDesktopSmall: [414, 3]

            });

    });
</script>
<!-- //banner-bottom-plugin -->
<!---<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css'>--->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="../../js/move-top.js"></script>
<script type="text/javascript" src="../../js/easing.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function($) {
        $(".scroll").click(function(event) {
            event.preventDefault();
            $('html,body').animate({
                scrollTop: $(this.hash).offset().top
            }, 1000);
        });
    });
</script>
<!-- Facebook Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
          'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', '2806909102866217');
      fbq('track', 'PageView');
  </script>
  <noscript><img height="1" width="1" style="display:none"
      src="https://www.facebook.com/tr?id=2806909102866217&ev=PageView&noscript=1"
      /></noscript>
      <!-- End Facebook Pixel Code -->
  <script type="module">
   import 'https://cdn.jsdelivr.net/npm/@pwabuilder/pwaupdate';
   const el = document.createElement('pwa-update');
   document.body.appendChild(el);
</script>
</head>
<style>
html, body {height: 100%;}
.content-container {margin-top:114px !important;min-height: 100%;height: unset !important;display: flex;flex-direction: column;}.content-section {background-color:#fff !important;flex: 1;}
.content-section2{width:100%;margin:0 auto;background: #fff;padding:10px 12%;text-align: center;}
.content-section4{width:100%;margin:0 auto;display:flex;justify-content:center;background: #f0f0f0;padding:0px 12%;text-align: center;}
.help{border-left: 2px solid #e5e5e5;border-right: 2px solid #fff;padding: 30px 40px;text-align: center;}.help img{display: block;margin: 0 auto;padding-bottom: 10px;width: 38px;height: 45px;}.help:hover{color: #ff6600;}.help:hover img{transform:scale(1.1,1.1);}
.content-section5{width:100%;margin:0 auto;background: #7f7f7f;padding:40px 12%;text-align: center;}.content-section5_info{display:flex;justify-content:center;}.foot_more, .foot_word, .foot_view{margin: 0 20px;color:#fff;width: 33%;}.foot_more_col{margin-bottom: 10px;}.foot_more_col a{color:#fff !important;margin: 0 10px;}.content-section5_copyright{color:#fff;margin-top: 10px;}.browser img{margin: 10px;width: 45px;}
.banner_real{background:url(../../images/viet/notice11.png) center 0px no-repeat;width: 100%;overflow: hidden;background-size:cover;height:435px;}
.panel-group .panel{border:none !important;border: none !important;box-shadow: 0 0 8px 1px #c5c5c5;background-color: transparent;margin: 20px 0 !important;padding: 20px;}.panel-heading{padding:0 !important;}.panel-body{border:0;border-top: none!important;background: transparent;}.qa{border-bottom: 1px solid #bcbcbc;padding: 5px 0;color: #f97f15;font-weight: 500;}
.game_inner{padding:10px 15%;width:100%; max-width:1300px;margin:0 auto;}.promotion_show{display:flex;}.promotion_show img{width: 70%;max-width: 676px;}
.promotion_info{background: #e2e2e2;padding:10% 10px;}.promotion_title{font-size:20px;}.more_button{margin: 0 20px;margin-top: 20px;text-align: center;background:#3b3b3b;color:#fff;border-radius: 10px;padding:8px 20px;}.orange{position: relative;background:#f97f00;display: flex;justify-content: center;align-items: center;}.service_banner{width: 100%;max-width: 200px;position: absolute;top:65%;left: 30%;transform: translate(-50%, -50%);}.banner_title{margin:3% 0 5% 0;font-size:22px;color: #fff;}.banner_title h1{color: #fff;font-size: 30px !important;font-weight: 900;}
.link_panel{display:flex;justify-content: space-between;color: #868686 !important;width: 100%;font-weight: 300;}.col_date{color: #868686 !important;width: 100%;font-weight:300;}.col_title{display: block;color: #111;font-size: 22px;margin: 5px 0;}.col_button{padding: 0px 12px;border: 1px solid #868686;border-radius: 20px;height: min-content;color: #868686 !important;}
@media screen and (max-width:770px) {.content-container {margin-top:84px !important}.logo_mobile img{height: 50px;width: auto;}.content-section4{padding:0px 3%;}.help{border-left: 1px solid #e5e5e5;border-right: 1px solid #fff;padding:8px;font-size: 12px;line-height: 18px;}.help img{padding-bottom: 8px;width: 22px;height: 28px;}.content-section5 {padding: 20px 6%;}.content-section5_info {flex-direction: column;}.foot_more, .foot_word, .foot_view {margin: 0;width: 100%;margin-bottom: 5px;}.browser img{width: 30px;}.banner_real{height:190px;}.game_inner{padding: 10px 3%;}
.promotion_show {display: block;}.promotion_show img {width: 100%;}.promotion_info {padding: 10px;}.more_button {margin: 0 40px;margin-top: 10px;padding: 5px 10px;}.foot_more, .foot_view{display:none;}.service_banner {width: 100%;max-width: 100px; position: absolute;top:60%;left: 20%;transform: translate(-50%, -50%);}.banner_title {margin: 3% 0 5% 38%;}}
</style>

<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KH7FG9T" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<!-- Messenger 洽談外掛程式 Code -->
<!--
<div id="fb-root"></div>
-->
<!-- Your 洽談外掛程式 code -->
<!--
<div id="fb-customer-chat" class="fb-customerchat"></div>
<script>
	var chatbox = document.getElementById('fb-customer-chat');
	chatbox.setAttribute("page_id", "100433372189785");
	chatbox.setAttribute("attribution", "biz_inbox");
	window.fbAsyncInit = function() {
		FB.init({
			xfbml: true,
			version: 'v12.0'
		});
	};
	(function(d, s, id) {
		var js, fjs = d.getElementsByTagName(s)[0];
		if (d.getElementById(id)) return;
		js = d.createElement(s);
		js.id = id;
		js.src = 'https://connect.facebook.net/vi_VN/sdk/xfbml.customerchat.js';
		fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));
</script>
<script type="text/javascript" src="../../js/jquery.js"></script>
<script type="application/x-javascript">
    addEventListener("load", function() {
        setTimeout(hideURLbar, 0);
    }, false);
    function hideURLbar() {
        window.scrollTo(0, 1);
    }
</script>
-->
<!-- //for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script type="text/javascript" src="../../js/jquery-2.1.4.min.js"></script>
<link href="../../css/mo/bootstrap91.css" rel="stylesheet" type="text/css" media="all" />
<link href="../../css/ch/style.css?202206141407" rel="stylesheet" type="text/css" media="all" />
<link type="text/css" rel="stylesheet" href="../../css/ch/docs.css" />
<link type="text/css" rel="stylesheet" href="../../css/ch/mmenu.css" />
<script src="../../css/ch/sweetalert.css"></script> 
<link rel="stylesheet" type="text/css" href="../../js/sweetalert.js">
<!-- js -->
<script type="text/javascript" src="../../js/jquery.mmenu.min.js"></script>
<script type="text/javascript">
    /*topbar左右選單*/
    //	The menu on the left
    $(function() {
        $('nav#menu-left').mmenu({
            searchfield: true,
            counters: true
        });
    });

    //	The menu on the right
    $(function() {
        $('nav#menu-right').mmenu({
            position: 'right',
            counters: true,
            searchfield: true
        });
        //	Click a menu-item
        var $confirm = $('#confirmation');
        $('#menu-right a').not('.mmenu-subopen').not('.mmenu-subclose').bind('click.example',function(e) {
			e.preventDefault();
			$confirm.show().text('You clicked "' + $(this).text() + '"');
			$('#menu-right').trigger('close');
		});
    });
</script>
<!-- //js -->
<script>
	if ('serviceWorker' in navigator) {
		console.log("Will service worker register?");
		navigator.serviceWorker.register('/service-worker.js').then(function(reg){
			//console.log("Yes it did.");
			console.log('Service worker registration succeeded:', reg);
		}).catch(function(err){
			console.log("No it didn't. This happened: ",err)
		});
	}else {
		console.log('Service workers are not supported.');
	}

	$(function() {
		let deferredPrompt;
		const divInstall = document.getElementById('installContainer');
		const butInstall = document.getElementById('butInstall');
		window.addEventListener('beforeinstallprompt',(event) => {
			// 防止迷你信息栏出现在移动设备上。
			event.preventDefault();
			console.log('OK','beforeinstallprompt', event);
			//alert('beforeinstallprompt');
			// 隐藏事件，以便以后再触发。
			window.deferredPrompt = event;
			deferredPrompt = event;
			// 从安装按钮容器中删除 'hidden' 类。
			//divInstall.classList.toggle('hidden', false); //<---- 暫關掉
		});

		window.addEventListener('appinstalled', (event) => {
			console.log('OK', 'appinstalled', event);
			// 回收 deferredPrompt 变量
			window.deferredPrompt = null;
		});

		//divInstall.classList.toggle('hidden', false);
		butInstall.addEventListener('click', async () => {
			console.log('OK', 'butInstall-clicked');
			const promptEvent = window.deferredPrompt;
			if (!promptEvent) {
				// 延迟提示不存在。
				//alert('延迟提示不存在')
				return;
			}
			// 显示安装提示。
			promptEvent.prompt();
			// Log the result
			const result = await promptEvent.userChoice;
			console.log('OK', 'userChoice', result);
			// 重置延迟提示变量，因为
			// prompt() 只能调用一次。
			window.deferredPrompt = null;
			// 隐藏安装按钮。
			divInstall.classList.toggle('hidden', true);
		});
	});
</script>
<!-- banner-bottom-plugin -->
<link href="../../css/mo/owl.carousel.css" rel="stylesheet" type="text/css" media="all">
<script src="../../js/owl.carousel.js"></script>
<script>
    $(document).ready(function() {
        $("#owl-demo").owlCarousel({
            autoPlay: 3000, //Set AutoPlay to 3 seconds
            items: 5,
            itemsDesktop: [640, 4],
            itemsDesktopSmall: [414, 3]
        });
    });
</script>
<link href="../../css/mo/ind2.css" rel="stylesheet" type="text/css" media="all" />
<!-- 未Đăng nhập前css -->
<!-- //banner-bottom-plugin -->
<!---<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,700italic,700,400italic,300italic,300' rel='stylesheet' type='text/css'>--->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="../../js/move-top.js"></script>
<script type="text/javascript" src="../../js/easing.js"></script>
<script type="text/javascript">
    jQuery(document).ready(function($) {
        $(".scroll").click(function(event) {
            event.preventDefault();
            $('html,body').animate({
                scrollTop: $(this.hash).offset().top
            }, 1000);
        });
    });
</script>
<script type="text/javascript">
    function Login() {
        $.blockUI();
        $('#frmLogin').submit();
    }
</script>
<style>
body, div, p, span, a, ul, li, ol, strong, tr, td, th{font-family: Times New Roman, Arial, Roboto, 微軟正黑體, sans-serif;}a{color: #5b5b5b !important;} a:hover{color:#ff6600!important;}body {-webkit-overflow-scrolling: touch;}
#header {position:fixed;top:0;width:100%;-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;height: auto;background-color:#fff;background-size: cover;padding: 0 !important;box-shadow: 0px 6px 16px rgba(20%,20%,40%,0.6), 0px 8px 18px rgba(20%,20%,40%,0.4), 0px 10px 12px rgba(20%,20%,40%,0.4);}
.gray{display:flex;align-items:center;justify-content:space-between;width:100%;height:38px;padding:0 20px;background-color: #e6e6e6;}
 .dropdown span,.dropdown a{color: #282828;}.btn-drop{background: transparent;border: none;padding: 0 5px;}#drop_sub{display: none;}
 .gray_right{display: flex;justify-content:space-between;align-items: center;}.gray_right div{margin: 0 5px;}.member_ID{font-weight: bold;font-size:15px;font-family: Arial, Helvetica, Verdana;}
 .member_wallet span{color:#ff6600;}.wallet_word{margin: 0;display: inline-block;}.mail{display: flex;align-items: center;}.mail_dot{background: #ff0000;width: 10px;height: 10px;position: relative;border-radius: 50%;right: 87px;top: -7px;}
 .mail a:hover{color:#ff6600;}
 .btn_gray{background-color: #606060;color: #fff !important;border-radius:5px;padding: 3px 15px;}.btn_gray:hover{background-color:#2d2d2d;color: #fff !important;}
 .btn_orange{background-color: #ff6600;color: #fff !important;border-radius:5px;padding:3px 15px;}.btn_orange:hover{background-color:#c34f01;color: #fff !important;}
 .white_bar{padding:10px 20px;display:flex;align-items:center;justify-content:space-between;width:100%;}
.showselect {display: flex;align-items: center;justify-content: space-between;}.main-menu {color: #5b5b5b;margin:0 20px;padding:8px 0;cursor: pointer;display: inline-block;}.main-menu:hover {color: #ff6600;}
.main-menu:hover>a:after{width: 100%;left: 0;}.main-menu a:after {content: "";position: absolute;right: 0;bottom:-6px;width: 0;border-bottom: 2px solid #ff6600;transition: width .3s;}
.top_title{position: relative;}.sub-menu {width:100%;left:0;top:93px;margin-top: 0px;min-height: 100px;background-color:#fff;opacity:0.9;padding: 0px;list-style-type: none;position: absolute;}
.sub-block{display:flex;align-items:center;justify-content:center;}.game{margin:30px;}
.game:hover>a:after{width: 100%;left: 0;}.game a:after {content: "";position: absolute;right: 0;bottom:-10px;width: 0;border-bottom: 2px solid;transition: width .3s;}
.ad{display: flex;justify-content: space-between;}.ad_inner{margin: 0 15px;}.ad_inner img{transform:scale(1,1);transition: all .3s ease-out;}.ad_inner img:hover{transform:scale(1.08,1.08);}
.man{position: relative;bottom: -5px;}.tool_inner{display:flex;align-items:center;justify-content:space-between;}.tool_inner img{width: 27px;filter: invert(38%) sepia(9%) saturate(0%) hue-rotate(271deg) brightness(85%) contrast(85%);margin:0 5px;}.tool_inner img:hover{filter:unset;}
.modal {display: none;position: fixed;z-index: 1;padding-top: 100px;left: 0;top: 0;width: 100%;height: 100%;overflow: auto;background-color: rgb(0,0,0);background-color: rgba(0,0,0,0.95);}
.modal-content {background-color: transparent;margin: auto;padding: 20px;border: 0;color: #fff;width: 80%;}
.close {color: #909090;position: absolute;right: 0;top: 0;font-size: 46px;font-weight: 100;text-shadow: none;}.close:hover {color: #909090;transition:0.5s;transform: rotatey(180deg);}
#panel > ul {display:flex;align-items:center;justify-content:center;flex-direction: column;list-style: none;}.ul_inner{display: flex;align-items: center;justify-content: space-between;}
.ul_inner li{padding:25px;margin:3px;width: 160px;height: 160px;border: 1px solid rgba(220,220,220,0.4);-webkit-transform: translate3d(0,0,0);transform: translate3d(0,0,0);-webkit-transition: -webkit-transform .2s ease-in-out 0s,background .2s ease-in-out 0s;transition: transform .2s ease-in-out 0s,background .2s ease-in-out 0s;}.ul_inner li:hover{background-color:#bd4d01;opacity:0.8;cursor:pointer;}
#panel > ul > li:before {content: "";display: block;padding-top: 100%;}#panel a{position: absolute;top: 50%;left: 50%;transform: translate(-50%, -50%);width: 100%;}
#panel .front {width: 100%;height: 100%;-webkit-transition: -webkit-transform .55s cubic-bezier(0.190,1.000,0.220,1.000) 0s,opacity .45s ease-in-out 0s;transition: transform .55s cubic-bezier(0.190,1.000,0.220,1.000) 0s,opacity .45s ease-in-out 0s;}.ul_inner li h3{margin:25px 0 10px 0 !important;color:#bdbdbd;font-size: 16px;font-weight:300;}.ul_inner li:hover h3{color:#fff;font-size:18px;}
.content-section4{width:100%;margin:0 auto;display:flex;justify-content:center;background: #f0f0f0;padding:0px 12%;text-align: center;}.help{border-left: 2px solid #e5e5e5;border-right: 2px solid #fff;padding: 30px 40px;text-align: center;}.help img{display: block;margin: 0 auto;padding-bottom: 10px;width: 38px;height: 45px;}.help:hover{color: #ff6600;}.help:hover img{transform:scale(1.1,1.1);}
.content-section5{width:100%;margin:0 auto;background: #7f7f7f;padding:40px 12%;text-align: center;}.content-section5_info{display:flex;justify-content:center;}.foot_more, .foot_word, .foot_view{margin: 0 20px;color:#fff;width: 33%;}.foot_more_col{margin-bottom: 10px;}.foot_more_col a{color:#fff !important;margin: 0 10px;}.foot_more_col a:hover{color:#ff6600 !important;}.content-section5_copyright{color:#fff;margin-top: 10px;}.browser img{margin: 10px;width: 45px;}.foot{}
.section2_inner a:hover .banner_pic{-webkit-filter: contrast(1.3);}.special_inner{padding: 5px 3%;}
.mobile_member > span {color:#fff;font-size:13px;padding: 4px 7px;font-weight: 300;}
.mobile_member > img{position:absolute;top: 50%;left: 50%;transform: translate(-50%,-50%);width: 15px;}
.mobile_member{display:none;position:relative;padding:0;width: 28px;height: 28px;border-radius: 50%;}input:focus{outline:none;border:1px solid #ff6600;}.back2021{display:none;}.back2021 img{width: 27px;margin: 0 5px;}
.tip {
    display: block;
    background: #f00;
    border-radius: 50%;
    width: 8px;
    height: 8px;
    right: 5px;
    top: -2px;
    position: absolute;
}
.tip2 {
    display: block;
    background: #f00;
    border-radius: 50%;
    width: 10px;
    height: 10px;
    right: 5px;
    top: -2px;
    position: absolute;
}
.tip3 {
    display: block;
    background: #f00;
    border-radius: 50%;
    width: 12px;
    height: 12px;
    left: -20px;
    top: 6%;
    position: absolute;
}

.coin_drop_btn{background: #bcbcbc;padding: 3px 6px;}
.coin_inner{display: flex!important;justify-content: space-between;}
.coin_inner span{color:#111;}
.onoffswitch {
	position: relative;
	width: 48px;
	margin: 0 0 0 5px !important;
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
}
.onoffswitch-checkbox {
    position: absolute;
    opacity: 0;
    pointer-events: none;
}
.onoffswitch-label {
    display: block; overflow: hidden; cursor: pointer;
    height: 20px; padding: 0; line-height: 20px;
    border: 2px solid #E3E3E3; border-radius: 20px;
    background-color: #FFFFFF;
    transition: background-color 0.3s ease-in;margin-bottom: 0;
}
.onoffswitch-label:before {
    content: "";
    display: block; width: 20px; margin: 0px;
    background: #FFFFFF;
    position: absolute; top: 0; bottom: 0;
    right: 26px;
    border: 2px solid #E3E3E3; border-radius: 20px;
    transition: all 0.3s ease-in 0s; 
}
.onoffswitch-checkbox:checked + .onoffswitch-label {
    background-color: #FF6600;
}
.onoffswitch-checkbox:checked + .onoffswitch-label, .onoffswitch-checkbox:checked + .onoffswitch-label:before {
	border-color: #FF6600;
}
.onoffswitch-checkbox:checked + .onoffswitch-label:before {
    right: 0px; 
}

@media only screen and (max-width:770px) {
	.back2021{display:block;}
	.gray{padding:0;}
	#unread{display:none;}
	.wallet_word{display:none;}
	.mail_dot{right:10px;}
	#welcome{display:none;}
	#member_button{display:none;}
	.showselect{display:none;}
	.white_bar{padding:3px 0px;}
	.logo_img {max-height:40px;}
	.modal-content {padding: 10px;width: 90%;}
	.close{top:-30px;}
	.front img{height:25px;max-width:30px;}
	.ul_inner li {padding:5px;width:100px;height:100px;}
	.ul_inner li h3 {margin: 12px 0 5px 0 !important;font-size:12px;}
	.ul_inner li:hover h3 {font-size:13px;}
	.game_name{font-size:13px;}
	.heart{position:unset;}
	.info_col_bottom{display:none;}
	.content-section4{padding:0px 3%;}
	.help{border-left: 1px solid #e5e5e5;border-right: 1px solid #fff;padding:8px;font-size: 12px;line-height: 18px;}
	.help img{padding-bottom: 8px;width: 22px;height: 28px;}
	.content-section5 {padding: 20px 6%;}
	.content-section5_info {flex-direction: column;}
	.foot_more, .foot_word, .foot_view {margin: 0;width: 100%;margin-bottom: 5px;}
	.browser img{width: 30px;}
	.mobile_member{display: block;}
}
.swal-overlay {z-index: 10000000000 !important;}
#installContainer {
  position: absolute;
  /*bottom: 1em;*/
  top: 0px;
  left: 0px;
  display: flex;
  justify-content: center;
  width: 20%;
  background-color:#2000E0;
}
#installContainer button {
  background-color: inherit;
  border: 1px solid white;
  color: white;
  font-size: 1em;
  padding: 0.75em;
}
.dis-n{display:none;}.dropdown-toggle::after {display:none !important;}
</style>

<body>
	<div id="installContainer" class="hidden">
		<button id="butInstall" type="button">Install</button>
	</div>
    <!-- Google Tag Manager (noscript) -->
    <noscript>
		<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KH7FG9T" height="0" width="0" style="display:none;visibility:hidden"></iframe>
	</noscript>
    <!-- End Google Tag Manager (noscript) -->
    <form id="gamefrm" method="get" action="" target="_blank"></form>
	<input type="hidden" id="islogin" value="0">
	<input type="hidden" id="rateeth" value="0">
	<input type="hidden" id="rateusdt" value="0">
	<input type="hidden" id="ratetrx" value="0">
	<div id="page">
		<div id="header">
			<div class="gray">
				<div class="gray_left">
					<div class="dropdown" id="drop_pc">
						<button type="button" class="btn-drop dropdown-toggle" id="dropdownMenu1" data-toggle="dropdown">
							<!--<img src="../../images/ch/english.png" style="width:38px" alt="">-->
							<span>English</span>
							<span class="caret"></span>
						</button>
						<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1" style="margin: 0px;left: unset !important;/*width:160px;*/width:80px;overflow: unset;min-width: unset;">
							<a role="menuitem" tabindex="-1" href="lang.php?q=viet&location=service_help3.php" style="background: none;width: auto;display:block;text-align:center;position: unset;"><!--<img src="../../images/ch/viet.png" style="width:38px" alt="">--><span>Tiếng Việt</span></a>
							<a role="menuitem" tabindex="-1" href="lang.php?q=cn&location=service_help3.php" style="background: none;width: auto;display:block;text-align:center;position: unset;"><!--<img src="../../images/ch/china.png" style="width:38px" alt="">--><span>简体</span></a>
							<a role="menuitem" tabindex="-1" href="lang.php?q=tw&location=service_help3.php" style="background: none;width: auto;display:block;text-align:center;position: unset;"><!--<img src="../../images/ch/taiwan.png" style="width:38px" alt="">--><span>繁體</span></a>
							<!--<a role="menuitem" tabindex="-1" href="lang.php?q=thai&location=service_help3.php" style="background: none;width: auto;display:block;text-align:center;position: unset;"><img src="../../images/ch/thai.png" style="width:38px" alt=""><span>ไทย(Thai)</span></a>-->
						</ul>
					</div>
				</div>
				<div class="gray_right">
										<div class="member_ID" id="welcome">Welcome</div>
					<div class="button_login_signup">
						<a href="login.php" class="btn_gray" type="button">Login</a>
						<a href="signup.php" class="btn_orange" type="button">Sign up</a>
					</div>
									</div>
			</div>
			<div class="white_bar">
				<a href="javascript:history.go(-1);" class="back2021">
					<img src="../../images/viet/back2021.svg">
				</a>
				<a href="index.php">
					<img src="../../images/ch/911vlogo_153x56.png" alt="911 Casino" class="logo_img">
				</a>
				<div class="showselect">
					<span class="main-menu">
						<a href="index.php" class="top_title">Home</a>
					</span>
					<span class="main-menu" onmouseover="switchMenu(this,'SubMenu2')" onmouseout="hideMenu()">
						<a href="game_sport.php" class="top_title">Sports</a>
						<ul id="SubMenu2" class="sub-menu" style="display:none;">
							<div class="sub-block">
								<div class="man">
									<img src="../../images/viet/man_sport.webp">
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_sport.php" class="top_title">CMD</a>
									</div>
									<div class="game">
										<a href="game_sport.php" class="top_title">UG Sports</a>
									</div>
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_sport.php" class="top_title">SABA Sports</a>
									</div>
									<div class="game">
										<a href="game_sport.php" class="top_title">IM e'SPORT</a>
									</div>
								</div>
								<!--
								<div class="ad">
									<div class="ad_inner">
										<a href="javascript:"><img src="../../images/viet/ad1.png"></a>
									</div>
									<div class="ad_inner">
										<a href="javascript:"><img src="../../images/viet/ad2.png"></a>
									</div>
								</div>
								-->
							</div>
						</ul>
					</span>
					<span class="main-menu" onmouseover="switchMenu(this,'SubMenu1')" onmouseout="hideMenu()">
						<a href="game_live.php" class="top_title">Live</a>
						<ul id="SubMenu1" class="sub-menu" style="display:none;">
							<div class="sub-block">
								<div class="game_col">
									<div class="game">
										<a href="game_live.php" class="top_title">EVO Live</a>
									</div>
									<div class="game">
										<a href="game_live.php" class="top_title">Sexy Live</a>
									</div>
									<div class="game">
										<a href="game_live.php" class="top_title">Allbet Live</a>
									</div>
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_live.php" class="top_title">Salong Live</a>
									</div>
									<div class="game">
										<a href="game_live.php" class="top_title">WM Live</a>
									</div>
									<div class="game">
										<a href="game_live.php" class="top_title">DG Live</a>
									</div>
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_live.php" class="top_title">AG Live</a>
									</div>
									<div class="game">
										<a href="game_live.php" class="top_title">XG Live</a>
									</div>
								</div>
								<!--
								<div class="ad">
									<div class="ad_inner">
										<a href="javascript:;"><img src="../../images/viet/ad1.png"></a>
									</div>
									<div class="ad_inner">
										<a href="javascript:"><img src="../../images/viet/ad2.png"></a>
									</div>
								</div>
								-->
								<div class="man">
									<img src="../../images/viet/girrl.webp">
								</div>
							</div>
						</ul>
					</span>
					<span class="main-menu" onmouseover="switchMenu( this, 'SubMenu3' )" onmouseout="hideMenu()">
						<a href="game_egame.php" class="top_title">E-games</a>
						<ul id="SubMenu3" class="sub-menu" style="display:none;">
							<div class="sub-block">
								<div class="game_col">
									<div class="game">
										<a href="game_egame.php" class="top_title">EVO E-games</a>
									</div>
									<div class="game">
										<a href="game_egame.php" class="top_title">IGSlot</a>
									</div>
									<div class="game">
										<a href="game_egame.php" class="top_title">CQ9</a>
									</div>
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_egame.php" class="top_title">V8</a>
									</div>
									<div class="game">
										<a href="game_egame.php" class="top_title">RICH</a>
									</div>
									<div class="game">
										<a href="game_egame.php" class="top_title">QTech</a>
									</div>
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_egame.php" class="top_title">BBIN Fishing</a>
									</div>
									<div class="game">
										<a href="game_egame.php" class="top_title">BBIN E-games</a>
									</div>
									<div class="game">
										<a href="game_egame.php" class="top_title">HC</a>
									</div>
								</div>
								<div class="man">
									<img src="../../images/viet/sharkk.webp">
								</div>
							</div>
						</ul>
					</span>
					<span class="main-menu" onmouseover="switchMenu( this, 'SubMenu4' )" onmouseout="hideMenu()">
						<a href="game_lottery.php" class="top_title">Lottery</a>
						<ul id="SubMenu4" class="sub-menu" style="display:none;">
							<div class="sub-block">
								<div class="man">
									<img src="../../images/viet/carcar.webp">
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_lottery.php" class="top_title">VSL Lottery</a>
									</div>
									<div class="game">
										<a href="game_lottery.php" class="top_title">BBIN Lottery</a>
									</div>
								</div>
								<div class="game_col">
									<div class="game">
										<a href="game_lottery.php" class="top_title">SC Lottery</a>
									</div>
									<div class="game">
										<a href="game_lottery.php" class="top_title">WinWin Lottery</a>
									</div>
								</div>
								<!--
								<div class="ad">
									<div class="ad_inner">
										<a href="javascript:"><img src="../../images/viet/ad1.png"></a>
									</div>
									<div class="ad_inner">
										<a href="javascript:"><img src="../../images/viet/ad2.png"></a>
									</div>
								</div>
								-->
							</div>
						</ul>
					</span>
					<span class="main-menu">
						<a href="promotion.php" class="top_title">Promotion</a>
					</span>
					<span class="main-menu">
						<a href="911vip.php" class="top_title" style="color:#ff6600 !important;">VIP</a>
					</span>
										<!--
					<span class="main-menu">
						<a href="promo_page30.php" class="top_title" style="color:#b91419 !important;">
							<img src="../../images/viet/red_bn1.png">New Year's Gift
						</a>
					</span>
					-->
					<!--
					<span class="main-menu">
						<a href="save_q.php" class="top_title">Deposit and Withdrawal Instructions</a>
					</span>
					-->
				</div>
				<div class="tool">
					<div class="tool_inner">
						<a href="service.php">
							<img src="../../images/viet/headphone.svg">
						</a>
						<a href="javascript:;" id="square_menu" style="position: relative;">
														<img src="../../images/viet/9dot.svg">
						</a>
					</div>
				</div>
			</div>
			<div id="myModal" class="modal">
				<div class="modal-content">
					<span class="close">&times;</span>
					<div id="panel">
						<ul>
							<div class="ul_inner">
								<li>
									<a href="index.php" class="pjx">
										<div class="front">
											<img src="../../images/viet/house2.png">
										</div>
										<h3>All games</h3>
									</a>
								</li>
								<li>
									<a href="promotion.php">
										<div class="front">
											<img src="../../images/viet/sale.png">
										</div>
										<h3>Promotion</h3>
									</a>
								</li>
								<li>
									<a href="notice.php">
										<div class="front">
											<img src="../../images/viet/bulletin.png">
										</div>
										<h3>Latest news</h3>
									</a>
								</li>
								<!--
								<li>
									<a href="user.php" class="gotobottom">
										<div class="front">
											<img src="../../images/viet/maintain.png">
										</div>
										<h3>維護時間</h3>
									</a>
								</li>
								-->
							</div>
							<div class="ul_inner">
								<li>
									<a href="https://www.facebook.com/911win911" target="_blank" class="gotobottom">
										<div class="front">
											<img src="../../images/viet/facebook_logos.png">
										</div>
										<h3>911 FB</h3>
									</a>
								</li>
																	
								<!--
								<li>
									<a href="https://appdn.911win.co/app/downloadapp2.php?lang=en">
										<div class="front">
											<img src="../../images/viet/APP.png">
										</div>
										<h3>Mobile shortcut download method</h3>
									</a>
								</li>
								-->
								<li>
									<a onclick="showGuide('ios')">
										<div class="front">
											<img src="../../images/viet/APP.png">
										</div>
										<h3>How to add a home screen shortcut on iOS</h3>
									</a>
								</li>
								<li>
									<a onclick="showGuide('android')">
										<div class="front">
											<img src="../../images/viet/APP.png">
										</div>
										<h3>How to add a home screen shortcut on Android</h3>
									</a>
								</li>
															</div>
																				</ul>
						<div id="mask"></div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!--手機捷徑教學 臨時擺放-->
	<style>
		.dlguide{padding-top: 100px;background:rgba(0,0,0,.8);cursor:pointer;display:none;height:100%;position:fixed;text-align:center;top:0;left:0;width:100%;z-index:10000;}.dlguide .helper{display:inline-block !important;height:100%;vertical-align:middle;background-image: none !important;}
		.dlguide > div {display: inline-block;height: auto;max-width: 551px;max-height: 800px;vertical-align: middle;width:85%;position: relative;border-radius: 8px;padding: 15px 5%;}
		.switch_btn{font-size:18px;text-shadow: none; line-height: 1.2;white-space: nowrap;text-overflow: ellipsis;font-weight: 700;cursor: pointer;background: #434756;border: none;padding: 10px 20px;text-align: center;vertical-align: middle;border-radius: 5px;color: #fff;}.switch_btn:hover{background:#5a5f72;}
		.guideCloseButton {background-color: transparent;border: 2px solid #ffac33;color: #ffac33;border-radius: 50px;cursor: pointer;display: inline-block;font-weight: bold;position: absolute;top: 5px;right: -25px;font-size: 30px;line-height: 30px;width: 35px;height: 35px;text-align: center;}
		.example{color: #20b5ff;text-decoration: underline;margin-bottom: 5px;font-size: 1.1em !important;}
		.guideCloseButton:hover {background-color: #ccc;}.mm_popup {cursor: pointer;}.mm_all{height: auto; text-align: left;}.mm_inner{padding: 20px;font-size: 16px;line-height: 22px;display:flex;border-bottom: 1px solid #ddd;}.mm_date{float: left;width:30%;text-align: center;}.mm_main{float: left;padding:0 10px;width:70%;}
		#iosPage img, #androidPage img{border-radius: 30px;box-shadow: 2px 2px 2px #ff9800, 4px 0px 6px rgb(255 152 0 / 80%), 6px 6px 12px rgb(255 152 0 / 80%);}
		@media only screen and (max-width: 770px) {.mm_all{height:400px; overflow:hidden; overflow-y:auto; -webkit-overflow-scrolling: touch;}.mm_inner {padding: 10px;font-size: 10px;}.mm_main {padding: 0 5px;}.dlguide .helper{height:70%;}
	</style>
	
	<div class="dlguide" id="iosGuide">
		<span class="helper" style="background-image: none !important;"></span>
		<div>
			<div class="guideCloseButton">X</div>
			<div class="mm_all">
				<div id="iosPage">
					<!--<img src="../../iosDownload/iosDownload_1.jpg">-->
				</div>
			</div>
			<br>
			<input class="switch_btn" type="button" onclick="backPage('ios')" value="< Prev">
            <input class="switch_btn" type="button" onclick="nextPage('ios')" value="Next >">
		</div>
	</div>
	
	<div class="dlguide" id="androidGuide">
		<span class="helper" style="background-image: none !important;"></span>
		<div>
			<div class="guideCloseButton">X</div>
			<div class="mm_all">
				<div id="androidPage">
					<!--<img src="../../androidDownload/androidDownload_1.jpg">-->
				</div>
			</div>
			<br>
			<input class="switch_btn" type="button" onclick="backPage('android')" value="< Prev">
            <input class="switch_btn" type="button" onclick="nextPage('android')" value="Next >">
		</div>
	</div>
	
	<script>
		var guidePage = 1;
		
		function showGuide(phoneType){
			guidePage = 1;
			$('#'+phoneType+'Guide').show();
			$('#'+phoneType+'Page').html('<img src="../../images/viet/' + phoneType + 'Download/' + guidePage + '.jpg" style="max-width: 100%; max-height: 100%;">');
		}
		
		function nextPage(phoneType){
			switch(phoneType){
				case 'ios':
					if(guidePage==5){
						$('#'+phoneType+'Guide').hide();
						return;
					}else{
						guidePage=guidePage+1;
					}
					break;
				case 'android':
					if(guidePage==4){
						$('#'+phoneType+'Guide').hide();
						return;
					}else{
						guidePage=guidePage+1;
					}
					break;
			}
			$('#'+phoneType +'Page').html('<img src="../../images/viet/' + phoneType + 'Download/' + guidePage + '.jpg" style="max-width: 100%; max-height: 100%;">');
		}
		
		function backPage(phoneType){
			if(guidePage==1){
				return;
			}else{
				guidePage=guidePage-1;
			}
			$('#'+phoneType+'Page').html('<img src="../../images/viet/' + phoneType + 'Download/' + guidePage + '.jpg" style="max-width: 100%; max-height: 100%;">');
		}
		
		$('.guideCloseButton').click(function(){
			$('#iosGuide').hide();
			$('#androidGuide').hide();
		});
	</script>
    <script type="text/javascript">
        var VisibleMenu = ''; // 記錄Hiện tại 顯示的子選單的 ID
        // 顯示或隱藏子選單
        function switchMenu(theMainMenu, theSubMenu, theEvent) {
            var SubMenu = document.getElementById(theSubMenu);
            if (SubMenu.style.display == 'none') { // 顯示子選單
                SubMenu.style.display = 'block';
                hideMenu(); // 隱藏子選單
                VisibleMenu = theSubMenu;
            } else { // 隱藏子選單
                if (theEvent != 'MouseOver' || VisibleMenu != theSubMenu) {
                    SubMenu.style.display = 'none';
                    VisibleMenu = '';
                }
            }
        }
        // 隱藏子選單
        function hideMenu() {
            if (VisibleMenu != '') {
                document.getElementById(VisibleMenu).style.display = 'none';
            }
            VisibleMenu = '';
        }
    </script>
    <script type="text/javascript" src="js/jquery.blockUI.js"></script>
    <script>
		var modal = document.getElementById("myModal");
		var btn = document.getElementById("square_menu");
		var span = document.getElementsByClassName("close")[0];
		btn.onclick = function() {
			modal.style.display = "block";
		}
		span.onclick = function() {
			modal.style.display = "none";
		}
		window.onclick = function(event) {
			if (event.target == modal) {
				modal.style.display = "none";
			}
		}
	</script>
	<script>
		$(document).ready(function(e) {
			setTopBalance('');
			getRate();
			window.setInterval("getRate()",60000);// 一分鐘更新
		});
		
		function setTopBalance(cur){
			$("#header_vnd").addClass("dis-n");
			$("#header_eth").addClass("dis-n");
			$("#header_trx").addClass("dis-n");
			$("#header_usdt").addClass("dis-n");
			$("#header_"+cur).removeClass("dis-n");
		}
		
		function getRate(){
			$.post("member_json4cyc.php", {
				act : 'getRate',
			},
			function(data, status) {
				var obj = JSON.parse(data);
				if (obj.code == "Ok") {
					$('#rateeth').val(obj.rateeth);
					$('#rateusdt').val(obj.rateusdt);
					$('#ratetrx').val(obj.ratetrx);
				} else {
				}
			});
		}		
	</script>
</body><!-- banner -->
<div class="content-container scrollable ng-scope" ui-view="" scrollable="">
	<div class="content-section">
		<div class="content">
			<div class="content-section">
				<div class="orange">
					<img src="../../images/viet/service.png" alt="" class="service_banner">
					<div class="banner_title"><h1>Service</h1>Common problem
					</div>
				</div>
			</div>
			<div class="game">
				<div class="game_inner">
					<div class="panel-group" id="accordion">
						
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne109">Is there a limit on the consignment amount?</a>
								</h4>
							</div>
							<div id="collapseOne109" class="panel-collapse collapse">
								<div class="panel-body">
									<p>At least 700,000 VNĐ for a single transaction</p>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne105">Is it possible to conduct consignment for 24 hours?</a>
								</h4>
							</div>
							<div id="collapseOne105" class="panel-collapse collapse">
								<div class="panel-body">
									<p>Yes, we provide 24-hour consignment service.</p>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne101">How long does it take for consignment to arrive?</a>
								</h4>
							</div>
							<div id="collapseOne101" class="panel-collapse collapse">
								<div class="panel-body">
									<p>We promise that, unless we encounter uncontrollable factors, we will provide the service to the account as soon as possible.</p>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne96">Why can&#039t I make consignment?</a>
								</h4>
							</div>
							<div id="collapseOne96" class="panel-collapse collapse">
								<div class="panel-body">
									<p>Please transfer the points of the game hall back to the main account balance<br />
The main account balance is less than 700,000 VND</p>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne58">Why was my consignment application rejected?</a>
								</h4>
							</div>
							<div id="collapseOne58" class="panel-collapse collapse">
								<div class="panel-body">
									<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-3e89b229-7fff-1171-7875-59b056330eb0"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">Please confirm whether you meet the transfer consignment instructions.</span></span></p>

<div>&nbsp;</div>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne57">How long does it take to complete the application for consignment transaction?</a>
								</h4>
							</div>
							<div id="collapseOne57" class="panel-collapse collapse">
								<div class="panel-body">
									<p><span id="docs-internal-guid-9221afab-7fff-cf82-cd70-546d5e1ac0c9"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">911 Casino provides 24-hour, all-year-round consignment transactions, and will be completed quickly within 3 minutes after you put forward the transaction request.</span></span></p>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne56">How do I apply for consignment?</a>
								</h4>
							</div>
							<div id="collapseOne56" class="panel-collapse collapse">
								<div class="panel-body">
									<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-7172ea0c-7fff-1e79-7772-87199bc7cb66"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">Go to the Member Center to [Consignment] to apply.</span></span></p>

<div>&nbsp;</div>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne55">Why is the record of my code washing query different from the record of the game?</a>
								</h4>
							</div>
							<div id="collapseOne55" class="panel-collapse collapse">
								<div class="panel-body">
									<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-7147517d-7fff-68bb-3626-b545021ac5bf"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">The system will update the code washing record every minute. As each game manufacturer has different access times to the game record, the time to capture the record will also be different. Please wait for a while and refresh it. If you still have problems, please take a screenshot. Deposit the certificate and contact our customer service.</span></span></p>

<div>&nbsp;</div>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne54">Why is my point balance different from what I see in the game?</a>
								</h4>
							</div>
							<div id="collapseOne54" class="panel-collapse collapse">
								<div class="panel-body">
									<p><span id="docs-internal-guid-96a9ba0f-7fff-aed1-061f-905b2a3715b9"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">Please wait a few minutes and click to refresh the content, or refresh the game page. If you still have problems after repeated attempts, please take a screenshot and contact our customer service.</span></span></p>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne53">How do I transfer points?</a>
								</h4>
							</div>
							<div id="collapseOne53" class="panel-collapse collapse">
								<div class="panel-body">
									<p><span id="docs-internal-guid-4034c1d9-7fff-8c79-c093-a4a17ad0c865"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">Please [recharge] first, and transfer points in the [quick transfer] on the game selection page. &quot;Transfer in&quot; can transfer the points into the game, and &quot;transfer out&quot; can transfer the points from the game to the main wallet.</span></span></p>

<p><span id="docs-internal-guid-274d98f7-7fff-f4bc-98f9-568aa89f2515"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">Please note: only points with integer digits are processed, and decimal digits cannot be transferred out.</span></span></p>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne52">Why do I need to transfer points to my wallet?</a>
								</h4>
							</div>
							<div id="collapseOne52" class="panel-collapse collapse">
								<div class="panel-body">
									<p><span id="docs-internal-guid-c49e2518-7fff-e365-db36-e85e6a52f0ef"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">Since 911 Casino cooperates with game manufacturers in a tandem manner, you must use the wallet transfer point to transfer the main wallet balance to each game before you can use it.</span></span></p>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne51">I have stored value, but the main wallet balance has not increased?</a>
								</h4>
							</div>
							<div id="collapseOne51" class="panel-collapse collapse">
								<div class="panel-body">
									<p>&nbsp;</p>

<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-f220dd16-7fff-593e-6f41-2f29e3b67368"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">Please confirm whether your payment amount is correct and the transfer is successful. The value can be successfully stored within 15 minutes after payment. If you have any related questions, please save your transfer information and contact our customer service.</span></span></p>

<div>&nbsp;</div>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne50">How can I top up?</a>
								</h4>
							</div>
							<div id="collapseOne50" class="panel-collapse collapse">
								<div class="panel-body">
									<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-45910f9c-7fff-5113-f45f-864a068f0c6a"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">After logging in to the member, go to [Recharge], select the amount you want to recharge and the payment method.</span></span></p>

<div>&nbsp;</div>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne49">Can the basic information be modified?</a>
								</h4>
							</div>
							<div id="collapseOne49" class="panel-collapse collapse">
								<div class="panel-body">
									<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-783ea967-7fff-7d5e-4ade-cc507874e364"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">The basic information cannot be modified once you fill in it. If you have any related questions, please contact our customer service.</span></span></p>

<div>&nbsp;</div>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne48">What should I do if I forget my password?</a>
								</h4>
							</div>
							<div id="collapseOne48" class="panel-collapse collapse">
								<div class="panel-body">
									<p><span id="docs-internal-guid-07fd0a4c-7fff-281a-c659-94773b01f97b"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">Please contact our customer service, we will serve you as soon as possible</span></span></p>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne47">What should I do if I don’t receive the verification code when verifying the SMS?</a>
								</h4>
							</div>
							<div id="collapseOne47" class="panel-collapse collapse">
								<div class="panel-body">
									<p><span id="docs-internal-guid-ae9d6ad0-7fff-608e-87fc-7c75efa42a99"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">Please resend the SMS verification request after 60 seconds. If the number of SMS verification has reached the upper limit, please contact our customer service and we will serve you as soon as possible.</span></span></p>

<p>&nbsp;</p>

<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-8a67c6b9-7fff-0f55-f340-8686683c0015"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">possible issues:</span></span></p>

<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-8a67c6b9-7fff-0f55-f340-8686683c0015"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">1. Please confirm whether your mobile phone number is filled in correctly.</span></span></p>

<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-8a67c6b9-7fff-0f55-f340-8686683c0015"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">2. Check whether your mobile phone is receiving well.</span></span></p>

<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-8a67c6b9-7fff-0f55-f340-8686683c0015"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">3. Does your own telecommunications company have services that block the &quot;Business Newsletter&quot;.</span></span></p>

<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-8a67c6b9-7fff-0f55-f340-8686683c0015"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">4. Is the capacity of mobile phone text messages insufficient?</span></span></p>

<p dir="ltr" style="line-height:1.38;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-8a67c6b9-7fff-0f55-f340-8686683c0015"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">5. Too many users use the SMS verification function, causing the line to be busy.MS khiến đường truyền nghẽn.</span></span></p>

<div>&nbsp;</div>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne46">Is my basic information safe?</a>
								</h4>
							</div>
							<div id="collapseOne46" class="panel-collapse collapse">
								<div class="panel-body">
									<p><span id="docs-internal-guid-ad08469c-7fff-741e-fc02-eab007c913ee"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">Here we can ensure that your personal information is safe and secure. 911 Casino insists on using the highest level of security measures and the most secure communication protocol (SSL 128-bit encryption standard), and storing it in the most secure operating environment, and the company Please rest assured that your personal information will never be disclosed to any third party.</span></span></p>

								</div>
							</div>
						</div>
												<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne45">What is the age requirement for membership?</a>
								</h4>
							</div>
							<div id="collapseOne45" class="panel-collapse collapse">
								<div class="panel-body">
									<p dir="ltr" style="line-height:1.38;margin-left: 36pt;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-645507bc-7fff-61c2-e97e-37e9018a2353"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">You need to agree to our terms and conditions, and you must be at least 18 years old or older.</span></span></p>

<p>&nbsp;</p>

<p dir="ltr" style="line-height:1.38;margin-left: 36pt;margin-top:0pt;margin-bottom:0pt;"><span id="docs-internal-guid-645507bc-7fff-61c2-e97e-37e9018a2353"><span style="font-size: 11pt; font-family: Arial; color: rgb(0, 0, 0); background-color: transparent; font-variant-numeric: normal; font-variant-east-asian: normal; vertical-align: baseline; white-space: pre-wrap;">Most countries have legally set relevant detailed regulations for online games. Please be sure to read and abide by your local legal provisions.</span></span></p>

<div>&nbsp;</div>

								</div>
							</div>
						</div>
												<!--<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title">
									<a data-toggle="collapse" data-parent="#accordion" 
									href="#collapseTwo">Vấn đề thường gặp</a>
								</h4>
							</div>
							<div id="collapseTwo" class="panel-collapse collapse">
								<div class="panel-body">
									<div class="qqq">
										<div class="qa" data-toggle="collapse" data-target="#b1">Website giải trí trực tuyến có hợp pháp không? ▾</div>
										<div id="b1" class="collapse">Hầu hết các quốc gia có các quy định chi tiết có liên quan đến trò chơi trực tuyến. Hãy đọc và tuân thủ các quy định pháp luật địa phương của bạn.</div>
									</div>
									<div class="qqq">
										<div class="qa" data-toggle="collapse" data-target="#b2">Yêu cầu về độ tuổi của hội viên ▾</div>
										<div id="b2" class="collapse">Bạn cần đồng ý với các điều khoản và điều kiện của chúng tôi; Đồng thời bạn phải từ 18 tuổi trở lên</div>
									</div>
									<div class="qqq">
										<div class="qa" data-toggle="collapse" data-target="#b3">Thông tin cơ bản của tôi được an toàn không? ▾</div>
										<div id="b3" class="collapse">Tại đây, chúng tôi có thể đảm bảo rằng thông tin cá nhân của bạn được an toàn và bảo mật. Website giải trí 911 khẳng định sử dụng các biện pháp bảo mật ở mức cao nhất và giao thức truyền thông an toàn nhất (tiêu chuẩn mã hóa SSL 128-bit) và lưu trữ thông tin đó trong môi trường hoạt động an toàn nhất. Hãy yên tâm rằng thông tin cá nhân của bạn sẽ không bao giờ được tiết lộ cho bất kỳ bên thứ ba nào.</div>
									</div>
									<div class="qqq">
										<div class="qa" data-toggle="collapse" data-target="#b4">Tôi nên làm gì nếu không nhận được mã OTP khi xác minh SMS? ▾</div>
										<div id="b4" class="collapse">Vui lòng gửi lại yêu cầu xác minh SMS sau 60 giây. Nếu số lần xác minh SMS đã vượt quá số lần quy định, vui lòng liên hệ với bộ phận CSKH của chúng tôi để được hỗ trợ trong thời gian sớm nhất.<br><br>
											Vui lòng lưu ý các vấn đề có thể xảy ra:<br>
											1. Vui lòng xác nhận xem số điện thoại di động của bạn đã được điền chính xác chưa.<br>
											2. Kiểm tra xem điện thoại di động của bạn có tốt không.<br>
											3. Nhà mạng bạn sử dụng có  trực thuộc có chặn tin quảng cáo không.<br>
											4. Dung lượng tin nhắn văn bản trên điện thoại di động có đủ không?<br>
											5. Quá nhiều người dùng sử dụng chức năng xác minh SMS khiến đường truyền nghẽn.
										</div>
									</div>
									<div class="qqq">
										<div class="qa" data-toggle="collapse" data-target="#b6">Tôi nên làm gì nếu quên mật khẩu? ▾</div>
										<div id="b6" class="collapse">Vui lòng liên hệ với bộ phận CSKH của chúng tôi để được hỗ trợ trong thời gian sớm nhất.</div>
									</div>
									<div class="qqq">
										<div class="qa" data-toggle="collapse" data-target="#b7">Có thể sửa thông tin cơ bản không? ▾</div>
										<div id="b7" class="collapse">Thông tin cơ bản không thể sửa đổi sau khi bạn điền vào. Nếu bạn có bất kỳ câu hỏi nào liên quan, vui lòng liên hệ với bộ phận CSKH.</div>
									</div>
									
								</div>
							</div>
						</div>-->
					</div>
					<div class="clear"></div>
				</div>
			</div>
		</div>
	</div>
</div>

<script src="../../js/bootstrap.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {

		$().UItoTop({
			easingType: 'easeOutQuart'
		});

	});
</script>
<style>
    
    .col-xs-12{background-color:#232323;border-top: 1px solid #424242;border-bottom: 1px solid #424242;margin-bottom:0px;display:block;}.index_icon{display: none;}.index_icon2{/*width:100%;*/width: 343px;height: 176px;}.index_tab{color:#fff;text-align:center;}.cashier-content .content-section {width: 100%;max-width:unset !important;min-width: 295px;}.nav-tabs{background:#ff6600;text-align:center;padding:0;}#myTab{display: flex;justify-content: space-around;background: transparent;padding-top: 10px;}
    .nav-tabs>li {float:none !important;margin-bottom: -1px;width:auto!important;max-width: 360px;display: inline-block !important;padding: 0 10px !important;text-align: center;box-sizing: border-box;}
    .tab1 li:hover>a:after, .tab1 .active a:after{width: 100%;left: 0;}.tab1 li a:after {content: "";position: absolute;right: 0;bottom:-6px;width: 0;border-bottom: 2px solid #fff;;transition: width .3s;}
    .nav-tabs>li.active>a, .nav-tabs>li.active>a:hover, .nav-tabs>li.active>a:focus {background: transparent !important;padding: 0 !important;margin:5px 0px;color: #fff !important;text-shadow: -1px -1px #ff6700, 1px 1px #333;font-size: 16px;}.nav-tabs>li>a:hover {color: #fff !important;text-shadow: -1px -1px #ff6700, 1px 1px #333;font-size: 16px;}
    .nav-tabs>li>a {background: transparent !important;padding: 0 !important;margin-right:0 !important;margin:5px 0px;border:0px !important;}
    .hot{margin:0 auto;margin-bottom:15px;text-align: center;color: #fff;font-size: 24px;}.tab1{background:none !important;margin:30px;}
    .swiper-container {width: 100%;height: 100%;}
    .swiper-slide {text-align:center;display: -webkit-box;display: -ms-flexbox;display: -webkit-flex;display: flex;-webkit-box-pack: center;-ms-flex-pack: center;-webkit-justify-content: center;justify-content: center;-webkit-box-align: center;-ms-flex-align: center;-webkit-align-items: center;align-items: center;}
    .slide_inner{background: #ff6600;border:2px solid #ffe846;overflow:hidden}.slide_inner:hover{border:2px solid #ff8a00;}.slide_inner:hover .info_col{background: rgb(255,103,0);background: linear-gradient(0deg, rgba(255,103,0,1) 0%, rgba(255,144,0,1) 100%, rgba(0,212,255,1) 100%);}
    .img_col img{width: 220px;height: 220px;transform:scale(1,1);transition: all .5s ease-out;}.slide_inner:hover .img_col img{transform:scale(1.1,1.1);}#outer-wp #content-wp.member dl#user-panel {padding-bottom: 0px !important;}
    .info_col{padding:15px;}.game_name{font-size: 16px;font-weight: 400;}.info_col div{color:#fff;}.info_col_top{display: flex;justify-content: space-between;margin-bottom:5px;}.info_col_bottom{display:flex;justify-content: flex-start;flex-direction:column;text-align:left;}.info_col_bottom img{margin:0 5px 5px 0;height:15px;width:15px;}
.heart {background: url(../../images/viet/web_heart_animation2.png);background-position: left;background-repeat: no-repeat;height: 50px;width: 50px;cursor: pointer;position: absolute;right:6px;bottom:52px;background-size:1450px;}.heart:hover{background-position: right; /*显示最后一个红心帧*/}
@-webkit-keyframes heartBlast {
0% {background-position: left;}
100% {background-position: right;}}
@keyframes heartBlast {
0% {background-position: left;}
100% {background-position: right;}}
.heartAnimation {-webkit-animation-name: heartBlast;animation-name: heartBlast;-webkit-animation-duration: .8s;animation-duration: .8s; -webkit-animation-iteration-count: 1;animation-iteration-count: 1;-webkit-animation-timing-function: steps(28); /*共28个背景图片帧*/animation-timing-function: steps(28);background-position: right;}
.content-section2{width:100%;margin:0 auto;background: #fff;padding:10px 12%;text-align: center;}.section2_title{margin-top:20px;margin-bottom:15px;font-size: 24px;color: #585858;}.section2_inner{display: inline-flex;justify-content: center;width: 100%;padding-top:2%;}.section2_right{margin-left:1px}.section2_left{margin-right:1px}.section2_left img, .section2_right img{width: 100%;margin:1px;}     

.special{margin-top:30px;padding:0 20px;display:flex;justify-content:space-between;}.content-section3{width:100%;margin:0 auto;background: #fff;padding:40px 12%;text-align: center;}
.special_title{font-size: 16px;color: #242424;font-weight: 400;margin: 5px 0;}.special_inner img{width: 50px;height: 50px;margin-bottom: 15px;}.special_time span{color: #ff6600;font-size: 50px;font-weight: 900;margin: 5px;}
.special_time {font-size: 20px;color: #ff6600;font-weight: 300;margin: 20px 0;vertical-align: inherit;}.plus{font-size: 20px !important;font-weight: 300 !important;vertical-align: super;}
.content-section4{width:100%;margin:0 auto;display:flex;justify-content:center;background: #f0f0f0;padding:0px 12%;text-align: center;}.help{border-left:0px solid #e5e5e5;border-right: 2px solid #e5e5e5;padding: 30px 40px;text-align: center;}.content-section4 a:nth-child(1) .help{border-left: 2px solid #e5e5e5;}.help img{display: block;margin: 0 auto;padding-bottom: 10px;width: 38px;height: 45px;}.help:hover{color: #ff6600;}.help:hover img{transform:scale(1.1,1.1);}
.content-section5{width:100%;margin:0 auto;background: #7f7f7f;padding:40px 0;text-align: center;}.content-section5_info{display:flex;justify-content:center;}.foot_more, .foot_word, .foot_view{margin:  0px;color:#fff;width: 33%;}.foot_more_col{margin-bottom: 10px;}.content-section5_copyright{color:#fff;margin-top: 10px;}.browser img{margin: 10px;width: 45px;}
.section2_inner a:hover .banner_pic{-webkit-filter: contrast(1.3);}.special_inner{padding: 5px 3%;}.pc_swiper{display:flex!important;}.hot_center{display:block !important;}.mobile_type{display:none;}.tab_bg{position: relative;}.tab_bg_img{width: 100%;}.right_item{position: absolute;z-index: 2;padding: 5px;right: 5%;width: 45%;top: 45%;left: 75%;transform: translate(-45%, -50%);}.right_item h1{margin:20px 0 5px 0;color: #fff;font-size: 30px !important;font-weight: 900;-webkit-transform: scale(1,1.5);-moz-transform: scale(1,1.5);-ms-transform: scale(1,1.5);-o-transform: scale(1,1.5);transform: scale(1,1.5);}.right_item h3{color: #fff;font-style: italic;}.right_item h4{color: #fff;font-size: 12px;font-weight: 200;}.right_item p{color: #fff;margin:25px 0 0 0;text-shadow: #000000c9 0.1em 0.1em 0.2em;word-wrap: break-word;}.down_btn{margin:15px 0 0 0;}.gray_btn{background: rgb(188,188,188);background: linear-gradient(90deg, rgba(188,188,188,1) 50%, rgba(241,241,241,1) 100%);border-radius: 20px;padding: 3px 20px;font-weight:400;margin: 0 0 8px 0;-moz-box-shadow: 4px 4px 12px -2px rgba(20%,20%,40%,0.5);-webkit-box-shadow: 4px 4px 12px -2px rgb(51 51 102 / 50%);box-shadow: 4px 4px 12px -2px rgb(51 51 102 / 50%);}.hole_btn{border-radius: 20px;border: 2px solid #fff;box-sizing: border-box;padding:2px 18px;font-weight: 400;color: #fff !important;}.hole_btn:hover{color:#fff !important;}.content-section6{display:none;}#myTab li{text-align:center;}
@media screen and (max-width:770px) {
    .foot_word{margin: 0 auto 18px auto !important;}
    .foot_more_col a {margin: 0 3%;width: 40%;}
    .mobile_type{display:none !important;}
    .mobile_type .help{width: unset;}
    .index_icon{width:95%;max-width:100px !important;display:-webkit-inline-box;}.index_icon2{display:none;}.mobile_gamehall{    z-index:11;
    display: block;
    background: #f4f4f4;
    position: fixed;
    top: 84px;
    width: 100%;
    padding-top: 15px;}.logo_mobile img{height: 50px;width: auto;}.cashier-content .content-section {padding-top:10px;}#outer-wp #content-wp.member dl#user-panel dt #left{display:none}#outer-wp #content-wp.member dl#user-panel ul.cash-info{display:none;}.col-xs-12{display:none;}.tab1 {margin:8px;}.nav-tabs{text-align:center;}.nav-tabs>li{display:inline-block !important;padding:0 !important;text-align: center;box-sizing: border-box;}.notice_title{display:none;}.top_marquee a {width:90%;}.nav-tabs > li > a {padding:0px !important;}.hot{margin-top:15px;}.img_col img{display:block;width: 100%;height: auto;}.info_col{padding:3px;}.info_col_top{justify-content:center;flex-direction:column;}.game_name{font-size:13px;}.heart{position:unset;}.info_col_bottom{display:none;}.content-section2{padding:10px 1%;}.shake1{bottom: 65%;right: 37%;width: 50% !important;}.shake2{bottom: 47%;right: 10%;width: 60% !important;}.shake3{bottom: 27%;right: 10%;width: 60% !important;}.shake4{bottom: 1%;right: 10%;width: 70% !important;}.content-section4{padding:0px 3%;}.help{width: 125px;border-left:0px solid #e5e5e5 !important;border-right:0px solid #fff !important;    padding: 6px 3px;font-size: 12px;line-height: 18px;}.help img{padding-bottom: 8px;width: 22px;height: 28px;}.content-section5 {padding: 20px 6%;}.content-section5_info {flex-direction: column;}.foot_more, .foot_word, .foot_view {margin: 0;width: 100%;margin-bottom: 5px;}.browser img{width: 30px;}.section2_inner {display: block;justify-content: unset;}.foot_more, .foot_view{display:block;}.mobile_type{display:block;background: #f4f4f4;}.content-section6{flex-wrap: wrap;justify-content: space-around;align-content: space-around;}}
      .h1,h1 {font-size: 1.1em !important;}
      #outer-wp #content-wp.member dl#user-panel ul.cash-info .icon {
        position: absolute;
        background: #fbbf85 !important;
        padding: 10px;
        width: 49px;
        height: 49px;
        border-radius: 100%;
        right: 20px;} 
@media screen and (max-width:578px){
    .mobile_type{display:block !important;}
    .content-section3{display:none;}
    .pc_swiper{display:none !important;}
}

    </style>
<div class="content-section6" style="grid-template-columns:20% 20% 20% 20% 20%;">
    <a href="service_help1.php">
        <div class="help"><img src="../../images/viet/new_h.png">About Us<!--關於我們--></div>
    </a>
    <a href="service_help2.php">
        <div class="help"><img src="../../images/viet/save_h.png">Deposit and withdrawal</div><!--存款與脫售說明（取代存款/取款幫助）-->
    </a>                            
    <a href="service_help3.php">
        <div class="help"><img src="../../images/viet/qq_h.png">Common problem</div><!--常见问题-->
    </a>
    <a href="service_help4.php">
        <div class="help"><img src="../../images/viet/teach_h.png">Game teaching</div><!--遊戲教學（文章分享）-->
    </a>
        <a href="service_help5.php">
        <div class="help"><img src="../../images/viet/cooperrr.png">Recommend to friends</div><!--推薦好友-->
    </a>  
	                       
</div>
<div class="content-section4 pc_swiper">
    <a href="service_help1.php">
        <div class="help"><img src="../../images/viet/new_h.png">About Us<!--關於我們--></div>
    </a>
    <a href="service_help2.php">
        <div class="help"><img src="../../images/viet/save_h.png">Deposit and withdrawal</div><!--存款與脫售說明（取代存款/取款幫助）-->
    </a>                            
    <a href="service_help3.php">
        <div class="help"><img src="../../images/viet/qq_h.png">Common problem</div><!--常见问题-->
    </a>
    <a href="service_help4.php">
        <div class="help"><img src="../../images/viet/teach_h.png">Game teaching</div><!--遊戲教學（文章分享）-->
    </a>
	    <a href="service_help5.php">
        <div class="help"><img src="../../images/viet/cooperrr.png">Recommend to friends</div><!--推薦好友-->
    </a>  
	</div>
<div class="content-section5">
    <div class="content-section5_info" style="display:unset">
        <div class="foot_more" style="width: 100%;margin-bottom: 18px;">
            <div class="foot_more_col">
                <a href="disclaimer.php">Betting responsibility</a>
                <a href="privacy.php">Privacy protection</a>
                <a href="service_terms.php">Gaming Responsibility</a>
                <a href="service_terms.php">Terms of Service</a>
            </div>
        </div>
        <!-- <div class="foot_word">hệ thống chúng tôi là công ty  giải trí hợp pháp đã được hội liên hiệp giải trí quốc tế cấp phép . để tham gia hệ thống vui lòng xác nhận bạn đã đủ 18 tuổi .</div>
        <div class="foot_view">Để có trải nghiệm tốt nhất khi tham gia . hệ thống đề xuất bạn nên sử dụng trình duyệt -->
        <div class="foot_word" style="margin:auto;">The system is a legal entertainment company licensed by the International Entertainment Association. Before signing up, please make sure you are over 18 years old.</div>
        <div class="foot_view" style="margin:auto;">For a better user experience, please use the recommended browser
                <div class="browser">
                <a href="https://www.google.com/intl/zh-TW/chrome/" target="_blank"><img src="../../images/viet/chrome.png"></a>
                <a href="https://www.mozilla.org/zh-TW/firefox/new/" target="_blank"><img src="../../images/viet/firefox.png"></a>
            </div>
        </div>
    </div>
    <div class="content-section5_copyright">2020 911 Casino All rights reserved</div>
</div></body>

</html>
<script>console.log("3")</script>